export type StockSymbol = 'AAPL' | 'TSLA' | 'MSFT' | 'GOOGL' | 'NVDA' | 'AMZN' | 'BTC-USD';

export interface StockDataPoint {
  date: string; // YYYY-MM-DD
  timestamp: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
  sentiment?: number; // range from -1 (extremely bearish) to 1 (extremely bullish)
}

export interface PredictionPoint {
  date: string;
  price: number;
  lowerBound?: number;
  upperBound?: number;
  isForecast: boolean;
}

export interface TechnicalIndicators {
  sma?: number;
  ema?: number;
  bollingerUpper?: number;
  bollingerLower?: number;
  regressionLine?: number;
}

export type ModelType = 'linear_regression' | 'exponential_smoothing' | 'moving_average' | 'polynomial_regression';

export interface ModelParams {
  modelType: ModelType;
  lookbackPeriod: number; // how many past days to use for training
  forecastHorizon: number; // 7, 14, 30, 90 days to predict
  smaPeriod: number;
  emaPeriod: number;
  smoothingAlpha: number; // For Exponential Smoothing (0 to 1)
  volatilityScenarios: 'normal' | 'bullish' | 'bearish';
}

export interface NewsArticle {
  id: string;
  title: string;
  source: string;
  publishedAt: string;
  impactSymbol: StockSymbol;
  sentiment: 'bullish' | 'bearish' | 'neutral';
  score: number; // -1 to 1
  summary: string;
  url?: string;
}

export interface PortfolioHolding {
  symbol: StockSymbol;
  shares: number;
  avgPurchasePrice: number;
}

export interface Transaction {
  id: string;
  timestamp: number;
  type: 'BUY' | 'SELL';
  symbol: StockSymbol;
  shares: number;
  price: number;
  totalCost: number;
}

export interface PortfolioState {
  cash: number;
  holdings: PortfolioHolding[];
  transactions: Transaction[];
}

export interface BacktestResult {
  mae: number;          // Mean Absolute Error
  rmse: number;         // Root Mean Squared Error
  mape: number;         // Mean Absolute Percentage Error (%)
  rSquared: number;     // R-squared score (fitting quality, -infinity to 1)
  directionAccuracy: number; // % of days model correctly predicted up/down day
  predictedVsActual: Array<{
    date: string;
    actual: number;
    predicted: number;
  }>;
}

export interface AIAnalysisReport {
  sentimentScore: number; // -100 to +100
  marketOutlook: 'STRONG_BUY' | 'BUY' | 'HOLD' | 'SELL' | 'STRONG_SELL';
  targetPriceRange: { min: number; max: number };
  probabilities: { bullish: number; neutral: number; bearish: number };
  executiveSummary: string;
  catalysts: string[];
  risks: string[];
  technicalAssessment: string;
}
