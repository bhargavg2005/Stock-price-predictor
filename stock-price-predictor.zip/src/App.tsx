import { useState, useMemo, useEffect } from 'react';
import { Header } from './components/Header';
import { ModelControls } from './components/ModelControls';
import { StockChart } from './components/StockChart';
import { Backtesting } from './components/Backtesting';
import { Portfolio } from './components/Portfolio';
import { AIForecaster } from './components/AIForecaster';
import { generateStockHistory, getPredictions, performBacktest, generateNewsFeed } from './utils/math';
import { StockSymbol, ModelParams, PortfolioState } from './types';
import { Quote, Sparkles, HelpCircle, ArrowUpRight, Award, Newspaper, Flame } from 'lucide-react';

export default function App() {
  // Current Stock Symbol Picker state
  const [selectedSymbol, setSelectedSymbol] = useState<StockSymbol>('AAPL');

  // Parameters state setting defaults for mathematical models
  const [params, setParams] = useState<ModelParams>({
    modelType: 'linear_regression',
    lookbackPeriod: 120,
    forecastHorizon: 30,
    smaPeriod: 20,
    emaPeriod: 20,
    smoothingAlpha: 0.15,
    volatilityScenarios: 'normal',
  });

  // Simulated live cash and holdings ledger state
  const [portfolio, setPortfolio] = useState<PortfolioState>({
    cash: 100000,
    holdings: [],
    transactions: []
  });

  // Generate and cache stock histories of all symbols on start to support true multi-asset valuations
  const stockHistoryMap = useMemo(() => {
    const map: Record<StockSymbol, ReturnType<typeof generateStockHistory>> = {
      AAPL: generateStockHistory('AAPL', 280),
      MSFT: generateStockHistory('MSFT', 280),
      NVDA: generateStockHistory('NVDA', 280),
      TSLA: generateStockHistory('TSLA', 280),
      GOOGL: generateStockHistory('GOOGL', 280),
      AMZN: generateStockHistory('AMZN', 280),
      'BTC-USD': generateStockHistory('BTC-USD', 280)
    };
    return map;
  }, []);

  // Recount current prices of all symbols
  const pricesMap = useMemo(() => {
    const map: Record<StockSymbol, number> = {
      AAPL: stockHistoryMap.AAPL[stockHistoryMap.AAPL.length - 1].close,
      MSFT: stockHistoryMap.MSFT[stockHistoryMap.MSFT.length - 1].close,
      NVDA: stockHistoryMap.NVDA[stockHistoryMap.NVDA.length - 1].close,
      TSLA: stockHistoryMap.TSLA[stockHistoryMap.TSLA.length - 1].close,
      GOOGL: stockHistoryMap.GOOGL[stockHistoryMap.GOOGL.length - 1].close,
      AMZN: stockHistoryMap.AMZN[stockHistoryMap.AMZN.length - 1].close,
      'BTC-USD': stockHistoryMap['BTC-USD'][stockHistoryMap['BTC-USD'].length - 1].close
    };
    return map;
  }, [stockHistoryMap]);

  // Read active pricing data
  const currentHistory = stockHistoryMap[selectedSymbol];
  const currentPrice = currentHistory[currentHistory.length - 1].close;
  const yesterdayPrice = currentHistory[currentHistory.length - 2].close;
  const priceChange = currentPrice - yesterdayPrice;
  const priceChangePercent = (priceChange / yesterdayPrice) * 100;

  // Recurse mathematical predictions dynamically based on lookback and params
  const { predictions, rSquared, stdError } = useMemo(() => {
    return getPredictions(currentHistory, params);
  }, [currentHistory, params]);

  // Recurse backtest scorecard dynamically
  const backtestResult = useMemo(() => {
    return performBacktest(currentHistory, params);
  }, [currentHistory, params]);

  // Handle refresh of all seeded historical datasets (for random variations)
  const [refreshSeed, setRefreshSeed] = useState<number>(0);
  const handleRefreshData = () => {
    window.location.reload(); // simple complete reset
  };

  // Process transaction ledgers
  const handleTrade = (type: 'BUY' | 'SELL', sharesCount: number) => {
    const tradePrice = currentPrice;
    const finalAmountCost = sharesCount * tradePrice;

    setPortfolio((prevPortfolio) => {
      const updatedHoldings = [...prevPortfolio.holdings];
      const existingHoldingIdx = updatedHoldings.findIndex(h => h.symbol === selectedSymbol);
      let updatedCash = prevPortfolio.cash;

      if (type === 'BUY') {
        updatedCash -= finalAmountCost;
        if (existingHoldingIdx >= 0) {
          const held = updatedHoldings[existingHoldingIdx];
          const totalShares = held.shares + sharesCount;
          const avgPrice = (held.shares * held.avgPurchasePrice + finalAmountCost) / totalShares;
          updatedHoldings[existingHoldingIdx] = {
            symbol: selectedSymbol,
            shares: totalShares,
            avgPurchasePrice: parseFloat(avgPrice.toFixed(4))
          };
        } else {
          updatedHoldings.push({
            symbol: selectedSymbol,
            shares: sharesCount,
            avgPurchasePrice: tradePrice
          });
        }
      } else {
        // SELL
        updatedCash += finalAmountCost;
        if (existingHoldingIdx >= 0) {
          const held = updatedHoldings[existingHoldingIdx];
          const remainingShares = held.shares - sharesCount;
          if (remainingShares <= 0) {
            updatedHoldings.splice(existingHoldingIdx, 1);
          } else {
            updatedHoldings[existingHoldingIdx] = {
              ...held,
              shares: remainingShares
            };
          }
        }
      }

      // Add record to ledger list
      const txId = `tx_${Date.now()}_${Math.random().toString(36).substr(2, 4)}`;
      const activeTxList = [
        ...prevPortfolio.transactions,
        {
          id: txId,
          timestamp: Date.now(),
          type,
          symbol: selectedSymbol,
          shares: sharesCount,
          price: tradePrice,
          totalCost: parseFloat(finalAmountCost.toFixed(2))
        }
      ];

      return {
        cash: parseFloat(updatedCash.toFixed(2)),
        holdings: updatedHoldings,
        transactions: activeTxList
      };
    });
  };

  // True accurate global Net Worth estimation (Liquid Cash + actual pricing valuation of owned assets)
  const portfolioNetWorth = useMemo(() => {
    const assetsValuationSum = portfolio.holdings.reduce((sum, h) => {
      const livePrice = pricesMap[h.symbol] || currentPrice;
      return sum + (h.shares * livePrice);
    }, 0);
    return portfolio.cash + assetsValuationSum;
  }, [portfolio, pricesMap, currentPrice]);

  // Render news sentinel feed based on selected ticker
  const activeNewsFeed = useMemo(() => {
    return generateNewsFeed(selectedSymbol);
  }, [selectedSymbol]);

  // String label of active parameters model
  const activeModelLabel = useMemo(() => {
    if (params.modelType === 'linear_regression') return 'Ordinary Least Squares Line';
    if (params.modelType === 'polynomial_regression') return 'Quadratic Polynomial Curve';
    if (params.modelType === 'exponential_smoothing') return "Holt's Double Smoothing";
    return 'Decaying Moving Average';
  }, [params.modelType]);

  return (
    <div id="stock-predictor-app" className="min-h-screen bg-[#060606] text-slate-100 flex flex-col font-sans">
      {/* Top Header Widget */}
      <Header
        selectedSymbol={selectedSymbol}
        setSelectedSymbol={setSelectedSymbol}
        currentPrice={currentPrice}
        priceChange={priceChange}
        priceChangePercent={priceChangePercent}
        onRefreshData={handleRefreshData}
        portfolioNetWorth={portfolioNetWorth}
      />

      {/* Main page layouts container */}
      <main className="max-w-7xl mx-auto w-full px-4 lg:px-6 py-8 flex-grow flex flex-col gap-6">
        
        {/* Dynamic Warning Alert for initial users explaining sandbox values */}
        <div className="bg-[#0A0A0A] border border-[#222] p-4 rounded-3xl text-left flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
          <div className="flex gap-3 items-start sm:items-center">
            <div className="bg-indigo-500/10 text-indigo-400 p-2 rounded-xl shrink-0 hidden sm:block">
              <Quote className="w-5 h-5 -scale-x-100" />
            </div>
            <div className="flex flex-col">
              <span className="text-xs font-bold text-slate-400 leading-none">Market Simulation Notice</span>
              <p className="text-[11px] text-slate-500 leading-relaxed mt-1">
                Data is generated securely using seeded Stochastic Brownian Motion. Tweak lookbacks, forecast parameters, and bias to backtest performance or test strategies dynamically!
              </p>
            </div>
          </div>
          <p className="text-[11px] font-mono font-bold text-slate-400 shrink-0">
            Active Model: <span className="text-indigo-400">{activeModelLabel}</span>
          </p>
        </div>

        {/* Core Layout Split Grid: Left configuration panel / Right analytics stage */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          
          {/* Left Column Sidebar: Sandbox Model controls + News updates feeds (Pushed to top on mobile) */}
          <div className="lg:col-span-4 flex flex-col gap-6">
            <ModelControls
              params={params}
              setParams={setParams}
              maxHistoryLength={currentHistory.length}
            />

            {/* News Sentinel items list */}
            <div id="news- sentinel-panel" className="bg-[#0A0A0A] border border-[#222] rounded-3xl p-5 shadow-xl text-left flex flex-col gap-4">
              <div className="flex items-center gap-2 border-b border-[#222] pb-3 justify-between">
                <span className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5 leading-none">
                  <Newspaper className="w-4 h-4 text-indigo-400" />
                  <span>Sentinel Financial Feeds</span>
                </span>
                <span className="text-[9px] font-bold text-slate-500 font-mono">
                  {selectedSymbol} Matches
                </span>
              </div>

              <div className="flex flex-col gap-4">
                {activeNewsFeed.map((news) => (
                  <div key={news.id} className="group flex flex-col gap-1 w-full text-left bg-transparent hover:bg-[#111] p-3 rounded-2xl border border-[#222] transition-colors">
                    <span className="text-[8.5px] font-bold font-mono text-slate-500 leading-none flex items-center justify-between">
                      <span>{news.source} • {news.publishedAt.split(',')[0]}</span>
                      <span className={`px-1 py-0.5 rounded uppercase font-bold text-[8px] tracking-wide border ${
                        news.sentiment === 'bullish'
                          ? 'bg-emerald-950/20 text-emerald-400 border-emerald-500/10'
                          : news.sentiment === 'bearish'
                          ? 'bg-rose-955/20 text-rose-400 border-rose-500/10'
                          : 'bg-slate-800 text-slate-400 border-slate-700/10'
                      }`}>
                        {news.sentiment}
                      </span>
                    </span>
                    <h4 className="text-[11.5px] font-bold text-white leading-snug pt-1 group-hover:text-indigo-400 transition-colors">
                      {news.title}
                    </h4>
                    <p className="text-[10px] text-slate-400 leading-normal font-light">
                      {news.summary}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Right Column Core Stage: SVGs + Backtest Scorecard + Paper Trading */}
          <div className="lg:col-span-8 flex flex-col gap-6">
            
            {/* Highly Polished SVG Chart */}
            <StockChart
              selectedSymbol={selectedSymbol}
              historicalData={currentHistory}
              predictions={predictions}
              lookbackPeriod={params.lookbackPeriod}
              forecastHorizon={params.forecastHorizon}
            />

            {/* Backtesting Engine scores */}
            <Backtesting
              symbol={selectedSymbol}
              backtestResult={backtestResult}
              modelName={activeModelLabel}
            />

            {/* Simulated virtual paper cash executor */}
            <Portfolio
              portfolioState={portfolio}
              selectedSymbol={selectedSymbol}
              currentPrice={currentPrice}
              onTrade={handleTrade}
            />

            {/* AI intelligence reports block */}
            <AIForecaster
              symbol={selectedSymbol}
              historicalPoints={currentHistory}
              currentPrice={currentPrice}
            />

          </div>

        </div>

      </main>

      {/* Aesthetic human literal credits footer */}
      <footer className="bg-[#0A0A0A] border-t border-[#222] py-6 text-center text-xs text-slate-500 flex flex-col gap-1 items-center justify-center">
        <p className="font-semibold text-slate-400">Stock Price Predictor Dashboard • Simulated Trading & Forecast Sandbox</p>
        <p className="text-slate-600">Quantitatively modeled using mathematical fits and Gemini AI intelligence reports.</p>
      </footer>
    </div>
  );
}
