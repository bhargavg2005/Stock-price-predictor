import { StockDataPoint, PredictionPoint, BacktestResult, ModelParams, StockSymbol, NewsArticle } from '../types';

// Seeded Random Number Generator for reproducible, high-quality synthetic data
export function createRNG(seedStr: string) {
  let h = 0;
  for (let i = 0; i < seedStr.length; i++) {
    h = Math.imul(31, h) + seedStr.charCodeAt(i) | 0;
  }
  return function() {
    h = Math.imul(h ^ h >>> 16, 2246822507);
    h = Math.imul(h ^ h >>> 13, 3266489909);
    return ((h ^= h >>> 16) >>> 0) / 4294967296;
  };
}

// Generate highly realistic synthetic stock price historical data
export function generateStockHistory(symbol: StockSymbol, daysCount: number = 300): StockDataPoint[] {
  const rng = createRNG(symbol + '_secret_seed_v2');
  
  // Set characteristics by symbol
  let basePrice = 150;
  let drift = 0.0003; // steady positive trend
  let volatility = 0.015; // daily movement range
  let trendCyclicalityAndFrequency = { ampl: 8, freq: 0.03 };

  switch (symbol) {
    case 'AAPL':
      basePrice = 175;
      drift = 0.0004;
      volatility = 0.012;
      trendCyclicalityAndFrequency = { ampl: 12, freq: 0.02 };
      break;
    case 'TSLA':
      basePrice = 190;
      drift = 0.0006;
      volatility = 0.032; // high volatility
      trendCyclicalityAndFrequency = { ampl: 35, freq: 0.04 };
      break;
    case 'MSFT':
      basePrice = 410;
      drift = 0.0005;
      volatility = 0.010; // stable giant
      trendCyclicalityAndFrequency = { ampl: 18, freq: 0.015 };
      break;
    case 'GOOGL':
      basePrice = 160;
      drift = 0.00045;
      volatility = 0.014;
      trendCyclicalityAndFrequency = { ampl: 10, freq: 0.025 };
      break;
    case 'NVDA':
      basePrice = 120;
      drift = 0.0018; // strong growth
      volatility = 0.028; // hyper volatility / momentum
      trendCyclicalityAndFrequency = { ampl: 20, freq: 0.05 };
      break;
    case 'AMZN':
      basePrice = 180;
      drift = 0.00035;
      volatility = 0.016;
      trendCyclicalityAndFrequency = { ampl: 14, freq: 0.03 };
      break;
    case 'BTC-USD':
      basePrice = 65000;
      drift = 0.0008; // high expansion
      volatility = 0.045; // extreme crypto volatility
      trendCyclicalityAndFrequency = { ampl: 8000, freq: 0.012 };
      break;
  }

  const data: StockDataPoint[] = [];
  let currentPrice = basePrice;
  const now = new Date();
  
  // We'll generate backward from current date
  const tempDates: Date[] = [];
  let d = new Date(now);
  
  while (tempDates.length < daysCount) {
    // Standard weekdays simulation (skip weekends)
    const day = d.getDay();
    if (day !== 0 && day !== 6) {
      tempDates.push(new Date(d));
    }
    d.setDate(d.getDate() - 1);
  }
  tempDates.reverse();

  // Build simulation series forward
  for (let i = 0; i < daysCount; i++) {
    const cycle = Math.sin(i * trendCyclicalityAndFrequency.freq) * trendCyclicalityAndFrequency.ampl;
    
    // Geometric Brownian Motion step
    const randomShock = (rng() - 0.5) * 2; // -1 to 1
    const newsShock = i % 25 === 0 ? (rng() - 0.5) * 6 : 0; // occasional earnings/corporate shocks
    
    const percentageReturn = drift + randomShock * volatility + (newsShock * volatility * 0.2);
    currentPrice = currentPrice * (1 + percentageReturn);
    
    // Add cyclical variance but bound from dipping below $1
    const adjustedClose = Math.max(1.0, currentPrice + cycle * (symbol === 'BTC-USD' ? 0.35 : 0.08));
    
    // Intraday spreads
    const priceVariance = adjustedClose * volatility * (0.8 + rng() * 0.6);
    const high = adjustedClose + priceVariance * rng();
    const low = Math.max(0.9, adjustedClose - priceVariance * rng());
    const open = low + rng() * (high - low);
    
    // Simulated volume with random bursts on high volatility days
    const baseVolume = symbol === 'BTC-USD' ? 25000 : 5000000;
    const volumeMultiplier = 1 + rng() * 1.5 + (Math.abs(percentageReturn) > volatility ? rng() * 3.0 : 0);
    const volume = Math.floor(baseVolume * volumeMultiplier);

    // Create a realistic rolling news/market sentiment marker
    const sentimentNoise = (rng() - 0.5) * 0.4;
    const priceReturnSentiment = Math.tanh(percentageReturn * 25);
    const sentiment = Math.min(1.0, Math.max(-1.0, priceReturnSentiment * 0.7 + sentimentNoise));

    const dateStr = tempDates[i].toISOString().split('T')[0];

    data.push({
      date: dateStr,
      timestamp: tempDates[i].getTime(),
      open: parseFloat(open.toFixed(symbol === 'BTC-USD' ? 2 : 3)),
      high: parseFloat(high.toFixed(symbol === 'BTC-USD' ? 2 : 3)),
      low: parseFloat(low.toFixed(symbol === 'BTC-USD' ? 2 : 3)),
      close: parseFloat(adjustedClose.toFixed(symbol === 'BTC-USD' ? 2 : 3)),
      volume,
      sentiment: parseFloat(sentiment.toFixed(2)),
    });
  }

  return data;
}

// Simple Moving Average
export function calculateSMA(data: number[], period: number): (number | null)[] {
  const sma: (number | null)[] = [];
  for (let i = 0; i < data.length; i++) {
    if (i < period - 1) {
      sma.push(null);
    } else {
      const sum = data.slice(i - period + 1, i + 1).reduce((acc, val) => acc + val, 0);
      sma.push(sum / period);
    }
  }
  return sma;
}

// Exponential Moving Average
export function calculateEMA(data: number[], period: number): (number | null)[] {
  const ema: (number | null)[] = [];
  if (data.length === 0) return [];
  
  const k = 2 / (period + 1);
  let currentEma = data[0]; // initialize with first price
  ema.push(currentEma);

  for (let i = 1; i < data.length; i++) {
    currentEma = data[i] * k + currentEma * (1 - k);
    ema.push(currentEma);
  }

  // Set the initial values as null if we want to mimic standard technical bounds (optional)
  // Here we let it fill gracefully, but we can set first few days to null to be precise
  for (let i = 0; i < Math.min(period - 1, ema.length); i++) {
    ema[i] = null;
  }
  return ema;
}

// Bollinger Bands (20-day SMA +/- 2 StdDev)
export function calculateBollingerBands(data: number[], period: number = 20, multiplier: number = 2): {
  upper: (number | null)[];
  lower: (number | null)[];
} {
  const upper: (number | null)[] = [];
  const lower: (number | null)[] = [];
  const smaList = calculateSMA(data, period);

  for (let i = 0; i < data.length; i++) {
    const sma = smaList[i];
    if (sma === null) {
      upper.push(null);
      lower.push(null);
    } else {
      const subset = data.slice(i - period + 1, i + 1);
      const mean = sma;
      const squaredDiffSum = subset.reduce((acc, val) => acc + Math.pow(val - mean, 2), 0);
      const stdDev = Math.sqrt(squaredDiffSum / period);
      upper.push(sma + multiplier * stdDev);
      lower.push(sma - multiplier * stdDev);
    }
  }

  return { upper, lower };
}

// Mathematical Core Prediction: Linear Regression Fit & Project
// Fits y = mx + c where x is the day index
export function runLinearRegression(
  historicalPrices: number[],
  lookbackCount: number,
  forecastDays: number,
  volScenario: 'normal' | 'bullish' | 'bearish' = 'normal'
): { predictions: number[]; rSquared: number; stdError: number } {
  const n = Math.min(lookbackCount, historicalPrices.length);
  const trainingData = historicalPrices.slice(-n);
  
  let sumX = 0;
  let sumY = 0;
  let sumXY = 0;
  let sumXX = 0;
  let sumYY = 0;

  for (let i = 0; i < n; i++) {
    const x = i;
    const y = trainingData[i];
    sumX += x;
    sumY += y;
    sumXY += x * y;
    sumXX += x * x;
    sumYY += y * y;
  }

  const denominator = n * sumXX - sumX * sumX;
  let slope = 0;
  let intercept = trainingData[trainingData.length - 1]; // fallback

  if (denominator !== 0) {
    slope = (n * sumXY - sumX * sumY) / denominator;
    intercept = (sumY - slope * sumX) / n;
  }

  // Calculate R-Squared and Standard Error on training set
  let sst = 0; // total sum of squares
  let ssr = 0; // residual sum of squares
  const meanY = sumY / n;

  for (let i = 0; i < n; i++) {
    const actual = trainingData[i];
    const predicted = slope * i + intercept;
    sst += Math.pow(actual - meanY, 2);
    ssr += Math.pow(actual - predicted, 2);
  }

  const rSquared = sst === 0 ? 0 : 1 - (ssr / sst);
  const stdError = Math.sqrt(ssr / Math.max(1, n - 2));

  // Predict future indices
  const predictions: number[] = [];
  // Volatility scalar adjustments for trend scenarios
  let scenarioDrift = 0;
  if (volScenario === 'bullish') {
    scenarioDrift = trainingData[trainingData.length - 1] * 0.0015; // +0.15% trend amplification per day
  } else if (volScenario === 'bearish') {
    scenarioDrift = -trainingData[trainingData.length - 1] * 0.0015; // -0.15% trend attenuation per day
  }

  for (let h = 1; h <= forecastDays; h++) {
    const targetIdx = n - 1 + h;
    const baseReg = slope * targetIdx + intercept;
    // ensure projection is smooth and never non-positive
    const val = Math.max(0.1, baseReg + scenarioDrift * h);
    predictions.push(val);
  }

  return { predictions, rSquared, stdError };
}

// Quadratic Polynomial Regression: fits y = ax^2 + bx + c
export function runPolynomialRegression(
  historicalPrices: number[],
  lookbackCount: number,
  forecastDays: number,
  volScenario: 'normal' | 'bullish' | 'bearish' = 'normal'
): { predictions: number[]; rSquared: number; stdError: number } {
  const n = Math.min(lookbackCount, historicalPrices.length);
  const trainingData = historicalPrices.slice(-n);

  // Set up matrices to solve quadratic Least Squares:
  // | sum X^4   sum X^3   sum X^2 | | a |   | sum X^2 Y |
  // | sum X^3   sum X^2   sum X   | | b | = | sum X Y   |
  // | sum X^2   sum X     n       | | c |   | sum Y     |
  let sumX = 0, sumX2 = 0, sumX3 = 0, sumX4 = 0;
  let sumY = 0, sumXY = 0, sumX2Y = 0;

  for (let i = 0; i < n; i++) {
    const x = i;
    const x2 = x * x;
    const y = trainingData[i];

    sumX += x;
    sumX2 += x2;
    sumX3 += x2 * x;
    sumX4 += x2 * x2;
    
    sumY += y;
    sumXY += x * y;
    sumX2Y += x2 * y;
  }

  // Solve the 3x3 linear system using Cramer's rule or fallback to linear
  const d = sumX4 * (sumX2 * n - sumX * sumX) - sumX3 * (sumX3 * n - sumX * sumX2) + sumX2 * (sumX3 * sumX - sumX2 * sumX2);
  
  let a = 0, b = 0, c = trainingData[trainingData.length - 1];

  if (Math.abs(d) > 1e-5) {
    const da = sumX2Y * (sumX2 * n - sumX * sumX) - sumX3 * (sumXY * n - sumY * sumX) + sumX2 * (sumXY * sumX - sumY * sumX2);
    const db = sumX4 * (sumXY * n - sumY * sumX) - sumX2Y * (sumX3 * n - sumX * sumX2) + sumX2 * (sumX3 * sumY - sumXY * sumX2);
    const dc = sumX4 * (sumX2 * sumY - sumX * sumXY) - sumX3 * (sumX3 * sumY - sumX2 * sumXY) + sumX2Y * (sumX3 * sumX - sumX2 * sumX2);

    a = da / d;
    b = db / d;
    c = dc / d;
  } else {
    // fallback to linear regression
    const linResult = runLinearRegression(historicalPrices, lookbackCount, forecastDays, volScenario);
    return linResult;
  }

  // Calculate stats
  let sst = 0, ssr = 0;
  const meanY = sumY / n;
  for (let i = 0; i < n; i++) {
    const actual = trainingData[i];
    const predicted = a * i * i + b * i + c;
    sst += Math.pow(actual - meanY, 2);
    ssr += Math.pow(actual - predicted, 2);
  }
  const rSquared = sst === 0 ? 0 : 1 - (ssr / sst);
  const stdError = Math.sqrt(ssr / Math.max(1, n - 3));

  // Future Prediction Projection
  const predictions: number[] = [];
  let scenarioDrift = 0;
  if (volScenario === 'bullish') {
    scenarioDrift = trainingData[trainingData.length - 1] * 0.001;
  } else if (volScenario === 'bearish') {
    scenarioDrift = -trainingData[trainingData.length - 1] * 0.001;
  }

  for (let h = 1; h <= forecastDays; h++) {
    const targetIdx = n - 1 + h;
    let val = a * targetIdx * targetIdx + b * targetIdx + c;
    
    // Dampen quadratic trends over far horizons to avoid extreme infinity fly-offs
    const dampening = 1 / (1 + 0.01 * h);
    val = trainingData[trainingData.length - 1] + (val - trainingData[trainingData.length - 1]) * dampening;

    predictions.push(Math.max(0.1, val + scenarioDrift * h));
  }

  return { predictions, rSquared, stdError };
}

// Double Exponential Smoothing (Holt's Linear Trend Forecaster)
export function runHoltsSmoothing(
  historicalPrices: number[],
  lookbackCount: number,
  forecastDays: number,
  alpha: number = 0.2, // smoothing factor for level
  beta: number = 0.1,  // smoothing factor for trend
  volScenario: 'normal' | 'bullish' | 'bearish' = 'normal'
): { predictions: number[]; rSquared: number; stdError: number } {
  const n = Math.min(lookbackCount, historicalPrices.length);
  const trainingData = historicalPrices.slice(-n);

  if (n < 3) {
    return {
      predictions: Array(forecastDays).fill(trainingData[trainingData.length - 1]),
      rSquared: 0,
      stdError: 0
    };
  }

  // Levels & Trend initialization
  let l = trainingData[1];
  let b = trainingData[1] - trainingData[0];
  
  const levels: number[] = [trainingData[0], l];
  const trends: number[] = [b, b];
  const fits: number[] = [trainingData[0], l];

  // Run over historical sequence
  for (let t = 2; t < n; t++) {
    const lastL = l;
    const lastB = b;
    const y = trainingData[t];

    l = alpha * y + (1 - alpha) * (lastL + lastB);
    b = beta * (l - lastL) + (1 - beta) * lastB;

    levels.push(l);
    trends.push(b);
    fits.push(lastL + lastB);
  }

  // Stats quality calculations
  let sumY = trainingData.reduce((acc, v) => acc + v, 0);
  const meanY = sumY / n;
  let sst = 0, ssr = 0;
  for (let i = 0; i < n; i++) {
    sst += Math.pow(trainingData[i] - meanY, 2);
    ssr += Math.pow(trainingData[i] - fits[i], 2);
  }
  const rSquared = sst === 0 ? 0 : 1 - (ssr / sst);
  const stdError = Math.sqrt(ssr / Math.max(1, n - 2));

  // Projects h-steps ahead: y_t+h = l_t + h * b_t
  const predictions: number[] = [];
  let scenarioDrift = 0;
  if (volScenario === 'bullish') {
    scenarioDrift = trainingData[trainingData.length - 1] * 0.0012;
  } else if (volScenario === 'bearish') {
    scenarioDrift = -trainingData[trainingData.length - 1] * 0.0012;
  }

  for (let h = 1; h <= forecastDays; h++) {
    const val = Math.max(0.1, l + h * b + scenarioDrift * h);
    predictions.push(val);
  }

  return { predictions, rSquared, stdError };
}

// Moving Average projecting (SMA forward projection)
export function runMovingAverageForecast(
  historicalPrices: number[],
  lookbackCount: number,
  forecastDays: number,
  period: number = 20,
  volScenario: 'normal' | 'bullish' | 'bearish' = 'normal'
): { predictions: number[]; rSquared: number; stdError: number } {
  const n = Math.min(lookbackCount, historicalPrices.length);
  const trainingData = historicalPrices.slice(-n);

  const smaList = calculateSMA(trainingData, period);
  const latestSma = smaList[smaList.length - 1] || trainingData[trainingData.length - 1];

  // Calculate fits
  let sst = 0, ssr = 0;
  let sumY = 0;
  let validCount = 0;

  for (let i = 0; i < n; i++) {
    const fitVal = smaList[i];
    if (fitVal !== null) {
      sumY += trainingData[i];
      validCount++;
    }
  }
  
  const meanY = validCount > 0 ? (sumY / validCount) : trainingData[trainingData.length - 1];

  for (let i = 0; i < n; i++) {
    const fitVal = smaList[i];
    if (fitVal !== null) {
      sst += Math.pow(trainingData[i] - meanY, 2);
      ssr += Math.pow(trainingData[i] - fitVal, 2);
    }
  }

  const rSquared = sst === 0 ? 0 : 1 - (ssr / sst);
  const stdError = Math.sqrt(ssr / Math.max(1, validCount - 1));

  // MA projection decays toward the average over time
  const predictions: number[] = [];
  const startVal = trainingData[trainingData.length - 1];
  let scenarioDrift = 0;
  if (volScenario === 'bullish') {
    scenarioDrift = startVal * 0.001;
  } else if (volScenario === 'bearish') {
    scenarioDrift = -startVal * 0.001;
  }

  for (let h = 1; h <= forecastDays; h++) {
    const weight = Math.exp(-h / 10); // exponential decays to SMA value
    const basePred = latestSma + (startVal - latestSma) * weight;
    predictions.push(Math.max(0.1, basePred + scenarioDrift * h));
  }

  return { predictions, rSquared, stdError };
}

// Master Prediction router applying requested model parameters
export function getPredictions(
  historicalPoints: StockDataPoint[],
  params: ModelParams
): {
  predictions: PredictionPoint[];
  rSquared: number;
  stdError: number;
} {
  const prices = historicalPoints.map(p => p.close);
  const forecastHorizon = params.forecastHorizon;
  const lookback = Math.min(params.lookbackPeriod, prices.length);

  let rawForecasts: number[] = [];
  let stats = { rSquared: 0, stdError: 0 };

  if (params.modelType === 'linear_regression') {
    const res = runLinearRegression(prices, lookback, forecastHorizon, params.volatilityScenarios);
    rawForecasts = res.predictions;
    stats = { rSquared: res.rSquared, stdError: res.stdError };
  } else if (params.modelType === 'polynomial_regression') {
    const res = runPolynomialRegression(prices, lookback, forecastHorizon, params.volatilityScenarios);
    rawForecasts = res.predictions;
    stats = { rSquared: res.rSquared, stdError: res.stdError };
  } else if (params.modelType === 'exponential_smoothing') {
    const res = runHoltsSmoothing(prices, lookback, forecastHorizon, params.smoothingAlpha, 0.1, params.volatilityScenarios);
    rawForecasts = res.predictions;
    stats = { rSquared: res.rSquared, stdError: res.stdError };
  } else if (params.modelType === 'moving_average') {
    const res = runMovingAverageForecast(prices, lookback, forecastHorizon, params.smaPeriod, params.volatilityScenarios);
    rawForecasts = res.predictions;
    stats = { rSquared: res.rSquared, stdError: res.stdError };
  }

  // Format prediction output list: historic training window + forecasted projected sequence
  const resultPoints: PredictionPoint[] = [];

  // 1. Add training data (historical window)
  const trainingPoints = historicalPoints.slice(-lookback);
  trainingPoints.forEach(p => {
    resultPoints.push({
      date: p.date,
      price: p.close,
      isForecast: false
    });
  });

  // 2. Add forecast projections with calculation interval ranges (Standard Error spreads)
  const lastPrice = prices[prices.length - 1];
  const lastDateStr = historicalPoints[historicalPoints.length - 1].date;
  const lastDate = new Date(lastDateStr + 'T12:00:00'); // Midday initialization to avoid TZ shifts

  rawForecasts.forEach((predPrice, index) => {
    // Increment weekdays only
    let currentDaysOffset = 0;
    let addedDays = 0;
    let targetDate = new Date(lastDate);

    while (addedDays <= index) {
      currentDaysOffset++;
      targetDate = new Date(lastDate.getTime() + currentDaysOffset * 24 * 60 * 60 * 1000);
      const isWeekend = targetDate.getDay() === 0 || targetDate.getDay() === 6;
      if (!isWeekend) {
        addedDays++;
      }
    }

    const dateStr = targetDate.toISOString().split('T')[0];
    
    // Confidence multiplier expands with horizon sqrt(index + 1)
    const errorSway = stats.stdError * 0.5 * Math.sqrt(index + 1);
    const lower = Math.max(0.1, predPrice - errorSway);
    // Exponential volatility expansion bounds
    const upper = pMaxBound(predPrice + errorSway, lastPrice * 3);

    resultPoints.push({
      date: dateStr,
      price: parseFloat(predPrice.toFixed(2)),
      lowerBound: parseFloat(lower.toFixed(2)),
      upperBound: parseFloat(upper.toFixed(2)),
      isForecast: true
    });
  });

  return {
    predictions: resultPoints,
    rSquared: Math.max(-5, parseFloat(stats.rSquared.toFixed(4))),
    stdError: parseFloat(stats.stdError.toFixed(3))
  };
}

function pMaxBound(val: number, bound: number): number {
  return isNaN(val) ? bound : Math.min(val, bound);
}

// Backtesting Engine Visual/Numeric Analysis
// Reserves last N days as actual validation, runs fitting models on the preceding training sets
export function performBacktest(
  historicalPoints: StockDataPoint[],
  params: ModelParams
): BacktestResult {
  const prices = historicalPoints.map(p => p.close);
  const totalDays = prices.length;

  // Let's set backtest target size (e.g., 30 days or 20% of history, min 10, max 60)
  const backtestValidationHorizon = Math.max(10, Math.min(60, Math.floor(totalDays * 0.15)));
  const splitIdx = totalDays - backtestValidationHorizon;

  const trainingSet = historicalPoints.slice(0, splitIdx);
  const actualValidationSet = historicalPoints.slice(splitIdx);
  
  const trainingPrices = trainingSet.map(p => p.close);
  const actualValidationPrices = actualValidationSet.map(p => p.close);

  let rawForecasts: number[] = [];
  const lookback = Math.min(params.lookbackPeriod, trainingPrices.length);

  // Train the model at the index of the split using exact same parameters
  if (params.modelType === 'linear_regression') {
    const res = runLinearRegression(trainingPrices, lookback, backtestValidationHorizon, 'normal');
    rawForecasts = res.predictions;
  } else if (params.modelType === 'polynomial_regression') {
    const res = runPolynomialRegression(trainingPrices, lookback, backtestValidationHorizon, 'normal');
    rawForecasts = res.predictions;
  } else if (params.modelType === 'exponential_smoothing') {
    const res = runHoltsSmoothing(trainingPrices, lookback, backtestValidationHorizon, params.smoothingAlpha, 0.1, 'normal');
    rawForecasts = res.predictions;
  } else if (params.modelType === 'moving_average') {
    const res = runMovingAverageForecast(trainingPrices, lookback, backtestValidationHorizon, params.smaPeriod, 'normal');
    rawForecasts = res.predictions;
  }

  // Calculate backtesting quality indicators
  let absoluteErrorSum = 0;
  let squaredErrorSum = 0;
  let percentageErrorSum = 0;
  
  let validDirectionChanges = 0;
  let totalDirectionalChecks = 0;

  const predictedVsActual: Array<{ date: string; actual: number; predicted: number }> = [];

  for (let i = 0; i < backtestValidationHorizon; i++) {
    const actual = actualValidationPrices[i];
    const predicted = rawForecasts[i];
    const date = actualValidationSet[i].date;

    const absDiff = Math.abs(actual - predicted);
    absoluteErrorSum += absDiff;
    squaredErrorSum += absDiff * absDiff;
    percentageErrorSum += (absDiff / actual);

    // Direction Accuracy comparison (did change in actual align with change in predicted week-over-week or day-by-day)
    if (i > 0) {
      const actualChange = actual - actualValidationPrices[i - 1];
      const predictedChange = predicted - rawForecasts[i - 1];
      
      const actualDir = actualChange >= 0 ? 1 : -1;
      const predictedDir = predictedChange >= 0 ? 1 : -1;

      if (actualDir === predictedDir) {
        validDirectionChanges++;
      }
      totalDirectionalChecks++;
    }

    predictedVsActual.push({
      date,
      actual: parseFloat(actual.toFixed(2)),
      predicted: parseFloat(predicted.toFixed(2))
    });
  }

  const mae = absoluteErrorSum / backtestValidationHorizon;
  const rmse = Math.sqrt(squaredErrorSum / backtestValidationHorizon);
  const mape = (percentageErrorSum / backtestValidationHorizon) * 100;
  const directionAccuracy = totalDirectionalChecks > 0 ? (validDirectionChanges / totalDirectionalChecks) * 100 : 100;

  // R-squared over validation set
  let sumActual = actualValidationPrices.reduce((a, b) => a + b, 0);
  const meanActual = sumActual / backtestValidationHorizon;
  let sst = 0, ssr = 0;

  for (let i = 0; i < backtestValidationHorizon; i++) {
    sst += Math.pow(actualValidationPrices[i] - meanActual, 2);
    ssr += Math.pow(actualValidationPrices[i] - rawForecasts[i], 2);
  }
  const rSquared = sst === 0 ? 1 : 1 - (ssr / sst);

  return {
    mae: parseFloat(mae.toFixed(2)),
    rmse: parseFloat(rmse.toFixed(2)),
    mape: parseFloat(mape.toFixed(2)),
    rSquared: parseFloat(rSquared.toFixed(4)),
    directionAccuracy: parseFloat(directionAccuracy.toFixed(1)),
    predictedVsActual
  };
}

// News generator with varying sentiment to mimic trading news releases
export function generateNewsFeed(symbol: StockSymbol): NewsArticle[] {
  const articles: { title: string; summary: string; score: number; sentiment: 'bullish' | 'bearish' | 'neutral' }[] = [];
  
  if (symbol === 'AAPL') {
    articles.push(
      {
        title: "Apple Announces revolutionary spatial-computing enhancements to device line",
        summary: "Market reactions are highly favorable. Analysts praise standard margins and strong chip efficiency.",
        score: 0.8,
        sentiment: 'bullish'
      },
      {
        title: "iPhone Supply chains face assembly adjustments in key centers",
        summary: "Shipping delay estimates are minor, but logistic and shipping fees could impact localized margins.",
        score: -0.3,
        sentiment: 'bearish'
      },
      {
        title: "Apple's subscription services segment logs double-digit growth",
        summary: "Services gross margin reaches a major high, highlighting excellent digital ecosystem retention.",
        score: 0.6,
        sentiment: 'bullish'
      }
    );
  } else if (symbol === 'TSLA') {
    articles.push(
      {
        title: "Tesla schedules next-gen full self driving computing rollout",
        summary: "Autopilot division shows notable milestones. Fans and retail investors show enthusiastic buy support.",
        score: 0.9,
        sentiment: 'bullish'
      },
      {
        title: "Global EV tax credits face shifting regulatory adjustments",
        summary: "Industry shifts may increase the cost of capital, potentially affecting short-term unit margin guides.",
        score: -0.5,
        sentiment: 'bearish'
      },
      {
        title: "Tesla Megapacks utility storage installations surge over 60%",
        summary: "Energy business vertical begins delivering a larger fraction of net operating margins.",
        score: 0.7,
        sentiment: 'bullish'
      }
    );
  } else if (symbol === 'NVDA') {
    articles.push(
      {
        title: "NVIDIA next-gen Blackwell chips achieve maximum factory production yield",
        summary: "Supercomputing cloud providers queue for high-density capacity. Demand outstrips supply massively.",
        score: 0.95,
        sentiment: 'bullish'
      },
      {
        title: "Tech consortia form alliances to standardise custom silicon alternatives",
        summary: "Competitors push alternative model acceleration frameworks. Analysts monitor competitive market share changes.",
        score: -0.4,
        sentiment: 'bearish'
      },
      {
        title: "NVIDIA software ecosystem locks record developer registrations",
        summary: "CUDA enterprise renewals exceed market expectations, creating durable software recurring revenues.",
        score: 0.75,
        sentiment: 'bullish'
      }
    );
  } else if (symbol === 'MSFT') {
    articles.push(
      {
        title: "Microsoft Cloud Azure revenue accelerates on corporate AI migrations",
        summary: "Enterprise contracts hit a multi-year high. Azure continues capturing market share against peers.",
        score: 0.85,
        sentiment: 'bullish'
      },
      {
        title: "Cybersecurity patch rollout encounters standard legacy compatibility flags",
        summary: "Operations report that patches require dynamic updates. Core operations are fully unimpacted.",
        score: -0.1,
        sentiment: 'neutral'
      },
      {
        title: "Office Productivity Suite releases dynamic automation assistants",
        summary: "Corporate seat licensing yields higher average revenue per user (ARPU), margins trend upward.",
        score: 0.6,
        sentiment: 'bullish'
      }
    );
  } else if (symbol === 'BTC-USD') {
    articles.push(
      {
        title: "Bitcoin institutional capital volume breaks previous yearly benchmarks",
        summary: "Custodial assets under management show a significant surge. Retail inflows are returning.",
        score: 0.85,
        sentiment: 'bullish'
      },
      {
        title: "Fed officials suggest prolonged high borrowing parameters",
        summary: "Macro risk-off sentiments take brief effect. Crypto markets adjust on short-term liquidity contraction.",
        score: -0.6,
        sentiment: 'bearish'
      },
      {
        title: "Historic block reward halving achieves seamless consensus execution",
        summary: "The daily supply issuance fell dynamically today. Miner operations report highly optimized processing efficiency.",
        score: 0.5,
        sentiment: 'bullish'
      }
    );
  } else {
    // defaults for google / amazon
    articles.push(
      {
        title: `${symbol} logs favorable quarterly metrics in recent operational files`,
        summary: "Earnings summary reports highlight balanced margins and sustained user expansion trends.",
        score: 0.4,
        sentiment: 'bullish'
      },
      {
        title: `${symbol} monitors general operational overhead adjustments`,
        summary: "Internal guides indicate corporate logistics might receive seasonal optimization cycles.",
        score: -0.2,
        sentiment: 'bearish'
      }
    );
  }

  return articles.map((art, idx) => ({
    id: `${symbol}_art_${idx}`,
    title: art.title,
    source: "Financial Oracle",
    publishedAt: new Date(Date.now() - idx * 12 * 3600 * 1000).toLocaleString(),
    impactSymbol: symbol,
    sentiment: art.sentiment,
    score: art.score,
    summary: art.summary,
  }));
}
