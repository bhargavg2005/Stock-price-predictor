import React from 'react';
import { Settings, Sliders, TrendingUp, Info } from 'lucide-react';
import { ModelParams, ModelType } from '../types';

interface ModelControlsProps {
  params: ModelParams;
  setParams: (params: ModelParams) => void;
  maxHistoryLength: number;
}

export function ModelControls({ params, setParams, maxHistoryLength }: ModelControlsProps) {
  const handleModelTypeChange = (modelType: ModelType) => {
    setParams({ ...params, modelType });
  };

  const handleLookbackChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setParams({ ...params, lookbackPeriod: parseInt(e.target.value) });
  };

  const handleSmoothingChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setParams({ ...params, smoothingAlpha: parseFloat(e.target.value) });
  };

  const handleSmaChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setParams({ ...params, smaPeriod: parseInt(e.target.value) });
  };

  const setForecastHorizon = (days: number) => {
    setParams({ ...params, forecastHorizon: days });
  };

  const setVolatilityScenario = (volatilityScenarios: 'normal' | 'bullish' | 'bearish') => {
    setParams({ ...params, volatilityScenarios });
  };

  const modelDescriptions: Record<ModelType, string> = {
    linear_regression: 'Fits a straight line (y = mx + b) across the selected historical days using Ordinary Least Squares, projecting structural momentum.',
    polynomial_regression: 'Solves quadratic polynomial equations (y = ax² + bx + c) to model curved trends, ideal for accelerating or decelerating markets.',
    exponential_smoothing: 'Employs Holt’s Linear Double Exponential Smoothing to predict trended historical data over discrete parameters.',
    moving_average: 'Projects a flat-forward SMA boundary, decaying current divergence slowly back towards rolling moving averages over horizons.',
  };

  return (
    <div id="model-controls-card" className="bg-[#0A0A0A] border border-[#222] rounded-3xl p-6 shadow-xl text-left flex flex-col gap-6">
      {/* Title Section */}
      <div className="flex items-center gap-2 border-b border-[#222] pb-4">
        <Settings className="w-5 h-5 text-indigo-400" />
        <h2 className="text-base font-bold text-white tracking-tight">Forecaster Sandbox</h2>
      </div>

      {/* Model Selection Menu */}
      <div className="flex flex-col gap-2">
        <label className="text-xs font-bold text-slate-400 uppercase tracking-widest flex items-center justify-between">
          <span>Mathematical Algorithm</span>
          <Sliders className="w-3.5 h-3.5 text-slate-500" />
        </label>
        
        <div className="grid grid-cols-2 gap-2 mt-1">
          {(['linear_regression', 'polynomial_regression', 'exponential_smoothing', 'moving_average'] as ModelType[]).map((t) => (
            <button
              key={t}
              onClick={() => handleModelTypeChange(t)}
              className={`p-2.5 rounded-2xl text-left border text-xs leading-tight transition-all cursor-pointer flex flex-col justify-between h-20 ${
                params.modelType === t
                  ? 'bg-indigo-600/10 border-indigo-500 text-indigo-400 shadow-md shadow-indigo-600/5'
                  : 'bg-[#111] border-[#222] text-slate-400 hover:border-[#333] hover:text-white'
              }`}
            >
              <span className="font-bold">
                {t === 'linear_regression' && 'Linear OLS'}
                {t === 'polynomial_regression' && 'Quadratic Poly'}
                {t === 'exponential_smoothing' && 'Holt\'s Double ES'}
                {t === 'moving_average' && 'MA Decay'}
              </span>
              <span className="text-[10px] text-slate-500 line-clamp-2 mt-1 font-normal leading-normal">
                {t === 'linear_regression' && 'y = mx + b OLS'}
                {t === 'polynomial_regression' && 'y = ax² + bx + c'}
                {t === 'exponential_smoothing' && 'Alpha + Beta trend'}
                {t === 'moving_average' && 'Rolling mean decay'}
              </span>
            </button>
          ))}
        </div>

        {/* Dynamic description info */}
        <div className="bg-[#111] border border-[#222] p-3 rounded-2xl flex gap-2 items-start mt-2">
          <Info className="w-4 h-4 text-slate-400 shrink-0 mt-0.5" />
          <p className="text-[11px] leading-relaxed text-slate-400">
            {modelDescriptions[params.modelType]}
          </p>
        </div>
      </div>

      {/* Slide Parameter Controls */}
      <div className="flex flex-col gap-4 bg-[#111] p-4 border border-[#222] rounded-2xl">
        {/* Lookback window days control */}
        <div className="flex flex-col gap-1.5">
          <div className="flex items-center justify-between text-xs font-semibold text-slate-404">
            <span>Lookback Training Window</span>
            <span className="font-mono bg-[#1C1C1E] border border-[#222] text-white px-2 py-0.5 rounded font-bold text-[10px]">
              {params.lookbackPeriod} Days
            </span>
          </div>
          <input
            type="range"
            min={20}
            max={Math.min(250, maxHistoryLength)}
            value={params.lookbackPeriod}
            onChange={handleLookbackChange}
            className="w-full accent-indigo-500 bg-[#1C1C1E] h-1.5 rounded-lg appearance-none cursor-pointer"
          />
          <span className="text-[10px] text-slate-550 text-right leading-none">
            Length of history fitted for regressions
          </span>
        </div>

        {/* Exponential Smoothing Coefficients */}
        {params.modelType === 'exponential_smoothing' && (
          <div className="flex flex-col gap-1.5 border-t border-[#222] pt-3">
            <div className="flex items-center justify-between text-xs font-semibold text-slate-404">
              <span>Smoothing Factor (Alpha)</span>
              <span className="font-mono bg-[#1C1C1E] border border-[#222] text-white px-2 py-0.5 rounded font-bold text-[10px]">
                {params.smoothingAlpha.toFixed(2)}
              </span>
            </div>
            <input
              type="range"
              min="0.05"
              max="0.95"
              step="0.05"
              value={params.smoothingAlpha}
              onChange={handleSmoothingChange}
              className="w-full accent-indigo-500 bg-[#1C1C1E] h-1.5 rounded-lg appearance-none cursor-pointer"
            />
            <span className="text-[10px] text-slate-550 leading-normal">
              Weighting of recent days vs history (closer to 1.0 weights recent days heavily)
            </span>
          </div>
        )}

        {/* SMA calculation Period */}
        {params.modelType === 'moving_average' && (
          <div className="flex flex-col gap-1.5 border-t border-[#222] pt-3">
            <div className="flex items-center justify-between text-xs font-semibold text-slate-404">
              <span>SMA Decay Baseline Period</span>
              <span className="font-mono bg-[#1C1C1E] border border-[#222] text-white px-2 py-0.5 rounded font-bold text-[10px]">
                {params.smaPeriod} Days
              </span>
            </div>
            <input
              type="range"
              min={5}
              max={50}
              step={1}
              value={params.smaPeriod}
              onChange={handleSmaChange}
              className="w-full accent-indigo-500 bg-[#1C1C1E] h-1.5 rounded-lg appearance-none cursor-pointer"
            />
            <span className="text-[10px] text-slate-550 leading-normal">
              Lookback for calculating the rolling average boundary to decay towards
            </span>
          </div>
        )}
      </div>

      {/* Forecast Horizon Days */}
      <div className="flex flex-col gap-2">
        <span className="text-xs font-bold text-slate-404 uppercase tracking-widest block">
          Forecast Horizon
        </span>
        <div className="grid grid-cols-4 gap-1.5 mt-1">
          {[7, 14, 30, 90].map((days) => (
            <button
              key={days}
              onClick={() => setForecastHorizon(days)}
              className={`py-2 rounded-xl text-center text-xs font-semibold border font-mono tracking-wide cursor-pointer transition-all ${
                params.forecastHorizon === days
                  ? 'bg-indigo-600 text-white font-bold border-indigo-500 shadow-md shadow-indigo-600/10'
                  : 'bg-[#111] border-[#222] text-[#888] hover:border-[#333] hover:text-white'
              }`}
            >
              +{days}d
            </button>
          ))}
        </div>
        <p className="text-[10px] text-slate-550 mt-0.5">
          Days of forward projections rendered with fitted standard error ranges
        </p>
      </div>

      {/* Projection Trend Bias scenarios */}
      <div className="flex flex-col gap-2">
        <span className="text-xs font-bold text-slate-404 uppercase tracking-widest block flex items-center gap-1">
          <TrendingUp className="w-3.5 h-3.5 text-indigo-400" />
          <span>Market Sentiment Bias</span>
        </span>
        <div className="grid grid-cols-3 gap-1.5 mt-1 bg-[#111] border border-[#222] p-1.5 rounded-2xl">
          {(['normal', 'bullish', 'bearish'] as const).map((bias) => (
            <button
              key={bias}
              onClick={() => setVolatilityScenario(bias)}
              className={`py-1.5 rounded-xl text-center text-xs font-semibold uppercase tracking-wider cursor-pointer transition-all ${
                params.volatilityScenarios === bias
                  ? bias === 'bullish'
                    ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-505/20 font-bold'
                    : bias === 'bearish'
                    ? 'bg-rose-500/15 text-rose-400 border border-rose-505/20 font-bold'
                    : 'bg-[#1C1C1E] border border-[#222] text-white font-bold'
                  : 'text-[#888] hover:text-white hover:bg-[#1C1C1E] border border-transparent'
              }`}
            >
              {bias}
            </button>
          ))}
        </div>
        <p className="text-[10px] text-slate-550 leading-normal mt-0.5">
          Simulated trend drifts injected on predictions based on hypothetical sentiment outcomes.
        </p>
      </div>
    </div>
  );
}
