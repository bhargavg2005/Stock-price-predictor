import { useState } from 'react';
import { Sparkles, Brain, Award, ShieldAlert, Zap, Compass, HelpCircle } from 'lucide-react';
import { AIAnalysisReport, StockSymbol, StockDataPoint } from '../types';

interface AIForecasterProps {
  symbol: StockSymbol;
  historicalPoints: StockDataPoint[];
  currentPrice: number;
}

export function AIForecaster({ symbol, historicalPoints, currentPrice }: AIForecasterProps) {
  const [report, setReport] = useState<AIAnalysisReport | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [errorHeader, setErrorHeader] = useState<string>('');
  const [errorMessage, setErrorMessage] = useState<string>('');

  const handleTriggerAnalysis = async () => {
    setLoading(true);
    setErrorHeader('');
    setErrorMessage('');
    setReport(null);

    // Prepare inputs matching API expectations
    const lastIdx = historicalPoints.length - 1;
    const highVal = Math.max(...historicalPoints.slice(-30).map(h => h.high));
    const lowVal = Math.min(...historicalPoints.slice(-30).map(h => h.low));
    
    // Compute simple moving averages for prompt context
    const closePrices = historicalPoints.map(p => p.close);
    const last20Close = closePrices.slice(-20);
    const sma20 = last20Close.reduce((a, b) => a + b, 0) / Math.max(1, last20Close.length);

    // Trend description
    const start30Price = closePrices[Math.max(0, closePrices.length - 30)];
    const endPrice = closePrices[closePrices.length - 1];
    const trendDir = endPrice > start30Price ? 'Bullish general uptrend' : 'Bearish overall downtrend';

    try {
      const newsFeedResult = await fetch('/api/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          symbol,
          currentPrice: endPrice,
          high: highVal,
          low: lowVal,
          trend: trendDir,
          lookbackDays: historicalPoints.length,
          indicators: {
            sma: sma20.toFixed(2),
            ema: (sma20 * 1.01).toFixed(2), // approximation
            bollingerUpper: (sma20 * 1.08).toFixed(2),
            bollingerLower: (sma20 * 0.92).toFixed(2),
            regressionLine: 'Historical slope trends upward at 0.12 coefficient per tick'
          },
          recentNews: [
            {
              title: `Advisory reports monitor regulatory actions around ${symbol}`,
              sentiment: 'neutral',
              score: 0.1,
              summary: `Institutional buyers are reviewing technical support parameters in light of broader macroeconomic shifts.`
            }
          ]
        })
      });

      const responseJSON = await newsFeedResult.json();

      if (!newsFeedResult.ok || responseJSON.error) {
        if (responseJSON.error === 'KeyMissing') {
          setErrorHeader('Gemini API Key Needed');
          setErrorMessage(responseJSON.message || 'API secret is missing. Enter your key in AI Studio Secrets.');
        } else {
          setErrorHeader('Analysis Query Interrupted');
          setErrorMessage(responseJSON.message || 'The backend was unable to parse report responses.');
        }
      } else if (responseJSON.report) {
         setReport(responseJSON.report);
      }
    } catch {
      setErrorHeader('Connection Exception');
      setErrorMessage('Unable to bridge server communication pipelines.');
    } finally {
      setLoading(false);
    }
  };

  // Determine market recommendation style classes
  const getOutlookStyle = (outlook: string) => {
    switch (outlook) {
      case 'STRONG_BUY':
        return 'text-emerald-400 bg-emerald-500/15 border-emerald-500/30';
      case 'BUY':
        return 'text-teal-400 bg-teal-500/15 border-teal-500/30';
      case 'HOLD':
        return 'text-amber-400 bg-amber-500/15 border-amber-500/30';
      case 'SELL':
        return 'text-orange-400 bg-orange-500/12 border-orange-500/20';
      case 'STRONG_SELL':
        return 'text-rose-400 bg-rose-500/15 border-rose-505/30';
      default:
        return 'text-slate-400 bg-slate-800 border-slate-705';
    }
  };

  return (
    <div id="ai-intelligence-panel" className="bg-[#0A0A0A] border border-[#222] rounded-3xl p-6 shadow-xl text-left flex flex-col gap-6 lg:col-span-12">
      {/* Title block */}
      <div className="flex items-center gap-2.5 border-b border-[#222] pb-4 justify-between flex-wrap gap-y-2">
        <div className="flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-indigo-400 animate-pulse" />
          <h2 className="text-base font-bold text-white tracking-tight">AI Quantitative Market Analysis</h2>
        </div>
        <span className="text-[10px] bg-indigo-600/10 text-indigo-400 border border-indigo-500/20 font-bold px-2 py-0.5 rounded font-mono uppercase tracking-wider flex items-center gap-1">
          <Brain className="w-3.5 h-3.5" />
          <span>Gemini Core Active</span>
        </span>
      </div>

      {/* Intro prompt */}
      {!report && !loading && !errorHeader && (
        <div className="py-8 px-4 flex flex-col items-center justify-center text-center max-w-lg mx-auto gap-4">
          <div className="bg-indigo-600/10 border border-indigo-500/20 p-4 rounded-2xl text-indigo-400 shadow-xl shadow-indigo-500/5 mb-2">
            <Brain className="w-9 h-9" />
          </div>
          <h3 className="text-lg font-bold text-white tracking-tight leading-none">Unlock Quantitative AI Analysis</h3>
          <p className="text-xs text-slate-400 leading-relaxed">
            Feed this asset's historical pricing, technical moving averages, fitted OLS boundaries, and market sentiment vectors into Gemini's multi-factorial neural engine to generate a deep-dive evaluation.
          </p>
          <button
            onClick={handleTriggerAnalysis}
            className="mt-2 bg-indigo-600 hover:bg-indigo-505 font-bold py-2.5 px-6 rounded-xl text-white text-xs flex items-center justify-center gap-2 cursor-pointer transition-transform duration-200 active:scale-95 shadow-xl shadow-indigo-600/10"
          >
            <Sparkles className="w-4 h-4" />
            <span>Generate Analysis Report</span>
          </button>
        </div>
      )}

      {/* Loading state indicator */}
      {loading && (
        <div className="py-12 flex flex-col items-center justify-center gap-5 text-center max-w-sm mx-auto">
          <div className="relative">
            <div className="w-14 h-14 rounded-full border-2 border-[#222] border-t-indigo-550 animate-spin"></div>
            <div className="absolute inset-0 flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-indigo-400 animate-pulse" />
            </div>
          </div>
          <div className="flex flex-col gap-1.5">
            <span className="text-xs font-bold text-indigo-400 uppercase tracking-widest block font-mono animate-pulse">Consulting Gemini Quant...</span>
            <p className="text-[11px] text-slate-500 leading-relaxed leading-normal">
              Evaluating pricing metrics, computing 30-day volatility coordinates, and parsing regulatory financial items...
            </p>
          </div>
        </div>
      )}

      {/* Error grace panel */}
      {errorHeader && (
        <div className="bg-[#111] border border-[#222] p-5 rounded-3xl text-left flex gap-4 items-start max-w-2xl mx-auto">
          <ShieldAlert className="w-8 h-8 text-rose-400 shrink-0 mt-0.5" />
          <div className="flex flex-col gap-1.5">
            <h4 className="text-sm font-bold text-white tracking-tight">{errorHeader}</h4>
            <p className="text-xs text-slate-400 leading-relaxed">
              {errorMessage}
            </p>
            {errorHeader.includes('API Key') && (
              <div className="mt-3 text-[11px] text-slate-500 border-t border-[#222] pt-3 flex flex-col gap-2 leading-relaxed">
                <span className="font-bold text-slate-400">How to populate your API key in development:</span>
                <ol className="list-decimal list-inside flex flex-col gap-1">
                  <li>Locate the <span className="text-slate-305 font-bold">Secrets</span> panel in the bottom-left sidebar of the AI Studio workspace.</li>
                  <li>Click Add Secret, write <span className="text-slate-300 font-mono font-bold">GEMINI_API_KEY</span> as the Name.</li>
                  <li>Paste your Gemini API key in the Value field, and save!</li>
                </ol>
                <button
                  onClick={handleTriggerAnalysis}
                  className="mt-2 text-indigo-400 hover:text-indigo-300 font-bold underline flex items-center gap-1 cursor-pointer self-start"
                >
                  <Sparkles className="w-3.5 h-3.5" /> Retry Analysis Query
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Main structured Report view */}
      {report && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          
          {/* Key metadata items metrics: Left Column */}
          <div className="lg:col-span-5 flex flex-col gap-4">
            {/* Visual outlook gauge */}
            <div className={`p-4 rounded-2xl border flex justify-between items-center ${getOutlookStyle(report.marketOutlook)}`}>
              <div className="flex flex-col">
                <span className="text-[9.5px] font-bold uppercase tracking-widest opacity-60">Quant Rating recommendation</span>
                <span className="text-xl font-extrabold tracking-tight mt-1">{report.marketOutlook.replace('_', ' ')}</span>
              </div>
              <Compass className="w-8 h-8 opacity-40 shrink-0" />
            </div>

            {/* Price targets & Sentiment ranges */}
            <div className="bg-[#111] border border-[#222] p-4 rounded-2xl flex flex-col gap-3 font-mono text-xs">
              <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block border-b border-[#222] pb-1.5 leading-none">
                30-Day Outlook Matrix
              </span>
              
              <div className="flex justify-between items-baseline mt-1 leading-none border-b border-[#222]/50 pb-2">
                <span className="text-slate-500 font-bold">Current Asset Index:</span>
                <span className="text-white font-extrabold text-sm">${currentPrice.toFixed(2)}</span>
              </div>

              <div className="flex justify-between items-baseline leading-none border-b border-[#222]/50 pb-2">
                <span className="text-slate-500 font-bold">Target Range forecast:</span>
                <span className="text-indigo-400 font-extrabold text-sm">
                  ${report.targetPriceRange.min.toFixed(2)} - ${report.targetPriceRange.max.toFixed(2)}
                </span>
              </div>

              <div className="flex justify-between items-baseline leading-none">
                <span className="text-slate-500 font-bold">Sentiment Score value:</span>
                <span className={`font-extrabold text-sm ${report.sentimentScore >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                  {report.sentimentScore > 0 ? '+' : ''}{report.sentimentScore}%
                </span>
              </div>

              {/* Sentiment Slider bar visualizer */}
              <div className="w-full bg-[#0A0A0A] h-2.5 rounded-full overflow-hidden relative mt-1.5 border border-[#222]">
                <div 
                  className={`h-full rounded-full ${report.sentimentScore >= 0 ? 'bg-emerald-500' : 'bg-rose-500'}`}
                  style={{
                    width: `${Math.abs(report.sentimentScore)}%`,
                    marginLeft: report.sentimentScore >= 0 ? '50%' : `${50 - Math.abs(report.sentimentScore)}%`
                  }}
                ></div>
                <div className="absolute inset-y-0 left-1/2 w-[1px] bg-[#222]"></div>
              </div>
            </div>

            {/* Probability Breakdown chart list */}
            <div className="bg-[#111] border border-[#222] p-4 rounded-2xl flex flex-col gap-2.5">
              <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block border-b border-[#222] pb-1.5 leading-none">
                Probability Distribution
              </span>

              {/* Horizontal stacked percentage pill */}
              <div className="w-full h-4 rounded-full bg-[#0A0A0A] overflow-hidden flex text-[9px] font-mono font-bold leading-normal mt-1 border border-[#222]">
                <div 
                  className="bg-emerald-500/80 text-emerald-950 text-center h-full flex items-center justify-center"
                  style={{ width: `${report.probabilities.bullish}%` }}
                >
                  {report.probabilities.bullish > 15 && `${Math.round(report.probabilities.bullish)}%`}
                </div>
                <div 
                  className="bg-slate-500/80 text-white text-center h-full flex items-center justify-center border-l border-r border-[#222]"
                  style={{ width: `${report.probabilities.neutral}%` }}
                >
                  {report.probabilities.neutral > 15 && `${Math.round(report.probabilities.neutral)}%`}
                </div>
                <div 
                  className="bg-rose-500/80 text-rose-950 text-center h-full flex items-center justify-center"
                  style={{ width: `${report.probabilities.bearish}%` }}
                >
                  {report.probabilities.bearish > 15 && `${Math.round(report.probabilities.bearish)}%`}
                </div>
              </div>
              
              <div className="flex justify-between text-[10px] font-mono text-slate-500 px-1 font-bold mt-1 leading-none">
                <span className="flex items-center gap-1.5 text-emerald-400">
                  <span className="inline-block w-2.5 h-2.5 rounded bg-emerald-500"></span> Upward ({Math.round(report.probabilities.bullish)}%)
                </span>
                <span className="flex items-center gap-1.5 text-slate-400">
                  <span className="inline-block w-2.5 h-2.5 rounded bg-slate-500"></span> Sideways ({Math.round(report.probabilities.neutral)}%)
                </span>
                <span className="flex items-center gap-1.5 text-rose-400 font-bold">
                  <span className="inline-block w-2.5 h-2.5 rounded bg-rose-500"></span> Downward ({Math.round(report.probabilities.bearish)}%)
                </span>
              </div>
            </div>
          </div>

          {/* Qualitative descriptive reports details: Right Column */}
          <div className="lg:col-span-7 flex flex-col gap-4">
            
            {/* Executive report text summaries */}
            <div className="bg-[#111] border border-[#222] p-4 rounded-2xl text-left flex flex-col gap-1.5">
              <span className="text-[10px] text-teal-400 font-bold uppercase tracking-wider block border-b border-[#222] pb-1.5 leading-none flex items-center gap-1">
                <Brain className="w-3.5 h-3.5" />
                <span>Executive Quant Summary</span>
              </span>
              <p className="text-xs text-slate-305 leading-relaxed leading-normal mt-1 pt-1">
                {report.executiveSummary}
              </p>
            </div>

            {/* Catalysts vs Downside risks columns split */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Catalysts bullet cards */}
              <div className="bg-emerald-950/10 border border-emerald-900/20 p-4 rounded-2xl flex flex-col gap-2">
                <span className="text-[10px] text-emerald-400 font-bold uppercase tracking-wider block leading-none flex items-center gap-1.5 pb-1 border-b border-emerald-900/10">
                  <Zap className="w-3.5 h-3.5" />
                  <span>Breakout Catalysts</span>
                </span>
                <ul className="list-disc list-inside flex flex-col gap-2 text-[11px] text-slate-300 pl-1 leading-relaxed leading-normal mt-1">
                  {report.catalysts.map((cat, idx) => (
                    <li key={`cat-${idx}`} className="align-top"><span className="text-slate-400">{cat}</span></li>
                  ))}
                </ul>
              </div>

              {/* Risks bullet cards */}
              <div className="bg-rose-950/10 border border-rose-900/20 p-4 rounded-2xl flex flex-col gap-2">
                <span className="text-[10px] text-rose-400 font-bold uppercase tracking-wider block leading-none flex items-center gap-1.5 pb-1 border-b border-rose-900/10">
                  <ShieldAlert className="w-3.5 h-3.5" />
                  <span>Downside Risk Triggers</span>
                </span>
                <ul className="list-disc list-inside flex flex-col gap-2 text-[11px] text-slate-300 pl-1 leading-relaxed leading-normal mt-1">
                  {report.risks.map((risk, idx) => (
                    <li key={`risk-${idx}`} className="align-top"><span className="text-slate-400">{risk}</span></li>
                  ))}
                </ul>
              </div>
            </div>

            {/* Technical visual assessment indicators review */}
            <div className="bg-[#111] border border-[#222] p-4 rounded-2xl text-left flex flex-col gap-1.5">
              <span className="text-[10px] text-indigo-300 font-bold uppercase tracking-wider block border-b border-[#222] pb-1.5 leading-none flex items-center gap-1">
                <Compass className="w-3.5 h-3.5 animate-spin-slow" />
                <span>Technical Indicators Assessment</span>
              </span>
              <p className="text-xs text-slate-400 leading-relaxed mt-1 leading-normal pt-1">
                {report.technicalAssessment}
              </p>
            </div>

            {/* Recalculate button */}
            <button
              onClick={handleTriggerAnalysis}
              className="self-end text-xs font-bold text-indigo-400 hover:text-[#bbb] underline cursor-pointer flex items-center gap-1"
            >
              <Sparkles className="w-3.5 h-3.5 animate-pulse" /> Re-execute AI Forecast analysis
            </button>
          </div>

        </div>
      )}

    </div>
  );
}
