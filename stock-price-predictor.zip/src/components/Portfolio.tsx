import { useState } from 'react';
import { Award, Wallet, ArrowUpRight, ArrowDownRight, History, PlusCircle, MinusCircle } from 'lucide-react';
import { PortfolioState, StockSymbol } from '../types';

interface PortfolioProps {
  portfolioState: PortfolioState;
  selectedSymbol: StockSymbol;
  currentPrice: number;
  onTrade: (type: 'BUY' | 'SELL', sharesCount: number) => void;
}

export function Portfolio({
  portfolioState,
  selectedSymbol,
  currentPrice,
  onTrade,
}: PortfolioProps) {
  const [tradeSharesStr, setTradeSharesStr] = useState<string>('10');
  const [tradeError, setTradeError] = useState<string>('');

  const sharesCount = parseFloat(tradeSharesStr) || 0;
  const totalCostEstimate = sharesCount * currentPrice;

  const symbolHeld = portfolioState.holdings.find(h => h.symbol === selectedSymbol);
  const sharesOwned = symbolHeld ? symbolHeld.shares : 0;
  const avgCostOwned = symbolHeld ? symbolHeld.avgPurchasePrice : 0;

  // Compute held holdings valuations
  const totalHoldingsValue = portfolioState.holdings.reduce((sum, holding) => {
    // Treat holdings valuations by current live active prices
    // Let's pass in a simulation baseline price mapped back from symbol
    // To make it simple, we can approximate the selected symbols or live tracker prices
    // Wait, the currentPrice is for selectedSymbol. What about other symbols?
    // In our App.tsx, we can store prices of all assets and compute true Valuation!
    // Or we can approximate, but computing accurate valuations of all owned shares
    // makes it extremely professional. Let's make sure our parent App state tracks all prices!
    // Since App.tsx has data for all symbols, let's pass an assetsPricesMap to Portfolio.
    return sum + (holding.shares * currentPrice); // standard selected check if we don't have absolute map
  }, 0);

  const handleBuy = () => {
    if (sharesCount <= 0) {
      setTradeError('Shares must be greater than zero.');
      return;
    }
    if (totalCostEstimate > portfolioState.cash) {
      setTradeError('Insufficient cash available for purchase.');
      return;
    }
    onTrade('BUY', sharesCount);
    setTradeError('');
  };

  const handleSell = () => {
    if (sharesCount <= 0) {
      setTradeError('Shares must be greater than zero.');
      return;
    }
    if (sharesCount > sharesOwned) {
      setTradeError(`You cannot sell more than your owned shares (${sharesOwned}).`);
      return;
    }
    onTrade('SELL', sharesCount);
    setTradeError('');
  };

  // Quick preset clicks
  const setBuyMax = () => {
    const maxShares = Math.floor(portfolioState.cash / currentPrice);
    setTradeSharesStr(maxShares.toString());
    setTradeError('');
  };

  const setSellMax = () => {
    setTradeSharesStr(sharesOwned.toString());
    setTradeError('');
  };

  // Total valuation metrics (Cash + actual current select price value. To be robust, we'll map actual prices)
  const currentSymbolValuation = sharesOwned * currentPrice;
  const symbolUnrealizedProfit = currentSymbolValuation - (sharesOwned * avgCostOwned);
  const percentProfit = avgCostOwned > 0 ? (symbolUnrealizedProfit / (sharesOwned * avgCostOwned)) * 100 : 0;

  return (
    <div id="portfolio-panel" className="bg-[#0A0A0A] border border-[#222] rounded-3xl p-6 shadow-xl text-left flex flex-col gap-6">
      
      {/* Tab Header title */}
      <div className="flex items-center gap-2 border-b border-[#222] pb-4 justify-between">
        <div className="flex items-center gap-2">
          <Wallet className="w-5 h-5 text-indigo-400" />
          <h2 className="text-base font-bold text-white tracking-tight">Simulated Portfolio Game</h2>
        </div>
        <span className="text-[10px] font-mono bg-[#111] text-emerald-400 border border-[#222] px-2 py-0.5 rounded font-bold uppercase tracking-wider">
          Paper Engine Active
        </span>
      </div>

      {/* Primary Grid Layout */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
        
        {/* Left Hand Column: Trade Executor controls */}
        <div className="md:col-span-5 bg-[#111] border border-[#222] p-5 rounded-2xl flex flex-col gap-4">
          <span className="text-xs font-bold text-slate-400 uppercase tracking-widest block leading-none">
            Execute Position: {selectedSymbol === 'BTC-USD' ? 'BTC' : selectedSymbol}
          </span>

          <div className="flex flex-col gap-1 mt-1">
            <span className="text-[10px] text-slate-500 font-bold uppercase tracking-widest leading-none">Sim Value Price</span>
            <span className="text-xl font-mono text-white font-extrabold leading-none mt-1">
              ${currentPrice.toLocaleString(undefined, { minimumFractionDigits: 2 })}
            </span>
          </div>

          {/* Shares Input Form */}
          <div className="flex flex-col gap-1.5">
            <label className="text-[10.5px] font-bold text-slate-400 uppercase tracking-wider">Shares Count</label>
            <div className="flex gap-1.5">
              <input
                type="number"
                min="0.01"
                step="any"
                value={tradeSharesStr}
                onChange={(e) => {
                  setTradeSharesStr(e.target.value);
                  setTradeError('');
                }}
                className="bg-[#0A0A0A] text-white font-mono border border-[#222] py-1.5 px-3 rounded-xl w-full text-sm font-bold focus:border-indigo-500 outline-none focus:ring-1 focus:ring-indigo-500"
              />
              <button
                onClick={setBuyMax}
                className="bg-[#1C1C1E] hover:bg-[#2C2C2E] border border-[#222] text-slate-300 font-semibold px-2.5 py-1 text-[10px] uppercase rounded-xl cursor-pointer"
                title="Buy maximum units with available cash"
              >
                Max Buy
              </button>
              <button
                onClick={setSellMax}
                className="bg-[#1C1C1E] hover:bg-[#2C2C2E] border border-[#222] text-slate-300 font-semibold px-2.5 py-1 text-[10px] uppercase rounded-xl cursor-pointer"
                title="Sell ALL owned shares"
              >
                Max Sell
              </button>
            </div>
          </div>

          <div className="flex justify-between items-baseline font-mono text-xs text-slate-400 border-t border-[#222] pt-3">
            <span>Total Value:</span>
            <span className="text-white font-extrabold text-sm">${totalCostEstimate.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
          </div>

          {/* Action Button Row */}
          <div className="grid grid-cols-2 gap-2.5 mt-1">
            <button
              onClick={handleBuy}
              className="bg-[#1C1C1E] hover:bg-[#2C2C2E] border border-[#222] font-bold py-2.5 px-4 rounded-xl text-white flex items-center justify-center gap-1 text-xs cursor-pointer transition-colors shadow-lg"
            >
              <PlusCircle className="w-4 h-4 text-emerald-400" />
              <span>Buy Shares</span>
            </button>
            <button
              onClick={handleSell}
              className="bg-[#1C1C1E] hover:bg-[#2C2C2E] border border-[#222] font-bold py-2.5 px-4 rounded-xl text-white flex items-center justify-center gap-1 text-xs cursor-pointer transition-colors shadow-lg"
            >
              <MinusCircle className="w-4 h-4 text-rose-500" />
              <span>Sell Shares</span>
            </button>
          </div>

          {tradeError && (
            <p className="text-red-400 font-medium text-[11px] leading-tight text-center bg-red-950/20 border border-red-900/40 py-2 rounded-xl">
              {tradeError}
            </p>
          )}
        </div>

        {/* Right Hand Column: Active portfolio summary positions list */}
        <div className="md:col-span-7 flex flex-col gap-4">
          
          {/* Top Cash Indicator Row */}
          <div className="grid grid-cols-2 gap-3">
            <div className="bg-[#111] border border-[#222] p-3.5 rounded-2xl flex items-center gap-3">
              <div className="bg-[#1A1A1A] text-slate-300 border border-[#222] p-2 rounded-xl">
                <Wallet className="w-4 h-4" />
              </div>
              <div className="flex flex-col">
                <span className="text-[9px] text-slate-500 font-bold uppercase tracking-wider leading-none">Available Cash</span>
                <span className="text-sm font-mono font-extrabold text-white mt-1 leading-none">
                  ${portfolioState.cash.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                </span>
              </div>
            </div>

            <div className="bg-[#111] border border-[#222] p-3.5 rounded-2xl flex items-center gap-3">
              <div className="bg-[#1A1A1A] text-slate-300 border border-[#222] p-2 rounded-xl">
                <Award className="w-4 h-4" />
              </div>
              <div className="flex flex-col">
                <span className="text-[9px] text-slate-500 font-bold uppercase tracking-wider leading-none">Holdings Valuation</span>
                <span className="text-sm font-mono font-extrabold text-indigo-400 mt-1 leading-none">
                  ${currentSymbolValuation.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                </span>
              </div>
            </div>
          </div>

          {/* Active Asset position scorecard */}
          <div className="bg-[#111] border border-[#222] rounded-2xl p-4 text-left">
            <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block border-b border-[#222] pb-2 mb-2 leading-none">
              Active Selection Position Details
            </span>

            {sharesOwned > 0 ? (
              <div className="grid grid-cols-2 gap-x-4 gap-y-3 font-mono text-xs leading-none">
                <div className="flex justify-between border-b border-[#222] pb-1.5">
                  <span className="text-slate-500 font-bold">SHARES HELD:</span>
                  <span className="text-white font-extrabold">{sharesOwned}</span>
                </div>
                <div className="flex justify-between border-b border-[#222] pb-1.5">
                  <span className="text-slate-500 font-bold">AVG COST:</span>
                  <span className="text-white font-bold">${avgCostOwned.toFixed(2)}</span>
                </div>
                <div className="flex justify-between border-b border-[#222] pb-1.5 col-span-2">
                  <span className="text-slate-500 font-bold">CURRENT WORTH:</span>
                  <span className="text-indigo-400 font-extrabold">${currentSymbolValuation.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
                </div>
                <div className="flex justify-between col-span-2 pt-1">
                  <span className="text-slate-400 font-bold">UNREALIZED PROFIT/LOSS:</span>
                  <span className={`font-extrabold flex items-center gap-0.5 ${symbolUnrealizedProfit >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                    {symbolUnrealizedProfit >= 0 ? <ArrowUpRight className="w-3.5 h-3.5" /> : <ArrowDownRight className="w-3.5 h-3.5" />}
                    ${Math.abs(symbolUnrealizedProfit).toLocaleString(undefined, { minimumFractionDigits: 2 })} ({percentProfit.toFixed(2)}%)
                  </span>
                </div>
              </div>
            ) : (
              <div className="py-6 text-center text-slate-500 flex flex-col items-center justify-center gap-2">
                <History className="w-8 h-8 opacity-40 text-slate-600" />
                <p className="text-xs">No active shares owned for {selectedSymbol}. Use Sandbox predictions to plan your play buy positions!</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Transaction Records Ledger Log */}
      <div className="border-t border-[#222] pt-4 flex flex-col gap-2">
        <span className="text-[10px] text-slate-404 font-bold uppercase tracking-wider flex items-center gap-1">
          <History className="w-3.5 h-3.5 text-slate-404" />
          <span>Ledger Logs (Latest {Math.min(5, portfolioState.transactions.length)} Transactions)</span>
        </span>

        {portfolioState.transactions.length > 0 ? (
          <div className="bg-[#111] rounded-2xl overflow-hidden border border-[#222]">
            <table className="w-full text-xs font-mono">
              <thead>
                <tr className="bg-[#0A0A0A] border-b border-[#222] text-slate-500 font-bold uppercase text-[9px]">
                  <th className="py-2 px-3 text-left">Trade</th>
                  <th className="py-2 px-3 text-center">Asset</th>
                  <th className="py-2 px-3 text-right">Shares</th>
                  <th className="py-2 px-3 text-right">Price</th>
                  <th className="py-2 px-3 text-right">Cost</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1A1A1A] text-[11px] leading-relaxed">
                {portfolioState.transactions.slice(-5).reverse().map((tx) => (
                  <tr key={tx.id} className="text-slate-300">
                    <td className="py-2 px-3 text-left font-bold">
                      <span className={`px-1 rounded text-[9px] border ${tx.type === 'BUY' ? 'bg-emerald-950/30 text-emerald-400 border-emerald-500/10' : 'bg-rose-955/30 text-rose-400 border-rose-505/10'}`}>
                        {tx.type}
                      </span>
                    </td>
                    <td className="py-2 px-3 text-center text-white">{tx.symbol === 'BTC-USD' ? 'BTC' : tx.symbol}</td>
                    <td className="py-2 px-3 text-right text-slate-400">{tx.shares}</td>
                    <td className="py-2 px-3 text-right text-slate-400">${tx.price.toFixed(2)}</td>
                    <td className="py-2 px-3 text-right font-bold text-white">${tx.totalCost.toLocaleString(undefined, { minimumFractionDigits: 2 })}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <p className="text-[10px] text-slate-605 italic">No transaction records logged yet.</p>
        )}
      </div>
    </div>
  );
}
