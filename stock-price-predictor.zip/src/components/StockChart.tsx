import React, { useState, useRef, useEffect } from 'react';
import { Eye, EyeOff, LayoutGrid } from 'lucide-react';
import { StockDataPoint, PredictionPoint, StockSymbol } from '../types';
import { calculateSMA, calculateEMA, calculateBollingerBands } from '../utils/math';

interface StockChartProps {
  selectedSymbol: StockSymbol;
  historicalData: StockDataPoint[];
  predictions: PredictionPoint[];
  lookbackPeriod: number;
  forecastHorizon: number;
}

interface ActiveTooltipData {
  date: string;
  price: number;
  open?: number;
  high?: number;
  low?: number;
  volume?: number;
  sma: number | null;
  ema: number | null;
  bbUpper: number | null;
  bbLower: number | null;
  lowerBound?: number;
  upperBound?: number;
  isForecast: boolean;
  x: number;
  y: number;
}

export function StockChart({
  selectedSymbol,
  historicalData,
  predictions,
  lookbackPeriod,
  forecastHorizon,
}: StockChartProps) {
  // Toggle overlay states
  const [showSMA, setShowSMA] = useState<boolean>(false);
  const [showEMA, setShowEMA] = useState<boolean>(false);
  const [showBollinger, setShowBollinger] = useState<boolean>(false);
  const [showConfidence, setShowConfidence] = useState<boolean>(true);
  const [timeframe, setTimeframe] = useState<'3M' | '6M' | '1Y' | 'ALL'>('1Y');

  // Interactive crosshair coordinates
  const [hoverData, setHoverData] = useState<ActiveTooltipData | null>(null);
  const svgRef = useRef<SVGSVGElement | null>(null);

  // Filter historical data based on selected timeframe filter
  const filterHistoricalByTimeframe = (): StockDataPoint[] => {
    let daysToTake = historicalData.length;
    if (timeframe === '3M') daysToTake = 65;
    else if (timeframe === '6M') daysToTake = 130;
    else if (timeframe === '1Y') daysToTake = 250;
    return historicalData.slice(-daysToTake);
  };

  const filteredHistory = filterHistoricalByTimeframe();

  // Combine filtered history + forecasted items
  // First, map historical points
  const combinedPoints: {
    date: string;
    price: number;
    open?: number;
    high?: number;
    low?: number;
    volume?: number;
    isForecast: boolean;
    lowerBound?: number;
    upperBound?: number;
  }[] = filteredHistory.map(h => ({
    date: h.date,
    price: h.close,
    open: h.open,
    high: h.high,
    low: h.low,
    volume: h.volume,
    isForecast: false
  }));

  // Now, get corresponding future forecasts from prediction points
  const forecastOnly = predictions.filter(p => p.isForecast);
  // Only take future forecasts up to active forecastHorizon
  const activeForecasts = forecastOnly.slice(0, forecastHorizon);

  activeForecasts.forEach(f => {
    combinedPoints.push({
      date: f.date,
      price: f.price,
      isForecast: true,
      lowerBound: f.lowerBound,
      upperBound: f.upperBound
    });
  });

  // Calculate technical indicators on combined series over history (this maintains continuity)
  // Fill values so overlay calculations align with points perfectly
  const historyPricesOnly = filteredHistory.map(h => h.close);
  const smaValues = calculateSMA(historyPricesOnly, 20);
  const emaValues = calculateEMA(historyPricesOnly, 20);
  const { upper: bbUpper, lower: bbLower } = calculateBollingerBands(historyPricesOnly, 20, 2);

  // SVG Dimension Math bounds
  const width = 850;
  const height = 440;
  const paddingLeft = 55;
  const paddingRight = 45;
  const paddingTop = 25;
  const paddingBottom = 40;
  const volumeChartHeightRange = 55;

  // Compute minimum and maximum prices over visible series for logical scaling
  const visiblePrices = combinedPoints.flatMap(cp => {
    const list = [cp.price];
    if (showConfidence && cp.isForecast && cp.lowerBound !== undefined && cp.upperBound !== undefined) {
      list.push(cp.lowerBound, cp.upperBound);
    }
    return list;
  });

  const rawMinPrice = Math.min(...visiblePrices);
  const rawMaxPrice = Math.max(...visiblePrices);
  
  // Pad prices range with 5% cushion above and below
  const priceMargin = (rawMaxPrice - rawMinPrice) * 0.05 || 5;
  const minPrice = Math.max(0, rawMinPrice - priceMargin);
  const maxPrice = rawMaxPrice + priceMargin;

  // Map indexes and prices to SVG screen coords
  const totalSlots = combinedPoints.length;
  
  const getX = (index: number): number => {
    const chartWidth = width - paddingLeft - paddingRight;
    return paddingLeft + (chartWidth * index) / Math.max(1, totalSlots - 1);
  };

  const getY = (price: number): number => {
    const chartHeight = height - paddingTop - paddingBottom - volumeChartHeightRange;
    const priceRange = maxPrice - minPrice || 1;
    return height - paddingBottom - volumeChartHeightRange - (chartHeight * (price - minPrice)) / priceRange;
  };

  const getVolY = (volume: number, maxVolume: number): number => {
    const containerBottom = height - paddingBottom;
    if (maxVolume === 0) return containerBottom;
    const heightScalar = (volumeChartHeightRange * volume) / maxVolume;
    return containerBottom - heightScalar;
  };

  const maxVolume = Math.max(...filteredHistory.map(h => h.volume), 1);

  // Trigger hover tracker
  const handleMouseMove = (e: React.MouseEvent<SVGSVGElement, MouseEvent>) => {
    if (!svgRef.current) return;
    const rect = svgRef.current.getBoundingClientRect();
    const cursorX = e.clientX - rect.left;
    
    // Convert relative screen cursor position back into data index
    const chartLeft = paddingLeft * (rect.width / width);
    const chartRight = (width - paddingRight) * (rect.width / width);
    const chartWidthPixels = chartRight - chartLeft;
    const pointerScale = (cursorX - chartLeft) / chartWidthPixels;
    const targetIdx = Math.round(pointerScale * (totalSlots - 1));

    if (targetIdx >= 0 && targetIdx < totalSlots) {
      const activeItem = combinedPoints[targetIdx];
      const isForecastPoint = activeItem.isForecast;

      // Extract indicators aligned with index if historical point
      // (aligned since historical sizes match)
      const hasIndicators = !isForecastPoint && targetIdx < filteredHistory.length;
      const sma = hasIndicators ? smaValues[targetIdx] : null;
      const ema = hasIndicators ? emaValues[targetIdx] : null;
      const bUpper = hasIndicators ? bbUpper[targetIdx] : null;
      const bLower = hasIndicators ? bbLower[targetIdx] : null;

      setHoverData({
        date: activeItem.date,
        price: activeItem.price,
        open: activeItem.open,
        high: activeItem.high,
        low: activeItem.low,
        volume: activeItem.volume,
        sma,
        ema,
        bbUpper: bUpper,
        bbLower: bLower,
        lowerBound: activeItem.lowerBound,
        upperBound: activeItem.upperBound,
        isForecast: isForecastPoint,
        x: getX(targetIdx),
        y: getY(activeItem.price)
      });
    } else {
      setHoverData(null);
    }
  };

  const handleMouseLeave = () => {
    setHoverData(null);
  };

  // Generate main area path definition
  const buildMainLinePath = (): string => {
    if (combinedPoints.length === 0) return '';
    let d = '';
    // Build first points over actual history
    const historyLength = filteredHistory.length;
    for (let i = 0; i < historyLength; i++) {
      const x = getX(i);
      const y = getY(combinedPoints[i].price);
      if (i === 0) d += `M ${x} ${y}`;
      else d += ` L ${x} ${y}`;
    }
    return d;
  };

  // Generate prediction overlay path
  const buildForecastPath = (): string => {
    const startIndex = filteredHistory.length - 1;
    if (startIndex < 0 || combinedPoints.length <= startIndex) return '';

    let d = `M ${getX(startIndex)} ${getY(combinedPoints[startIndex].price)}`;
    for (let i = startIndex; i < combinedPoints.length; i++) {
       d += ` L ${getX(i)} ${getY(combinedPoints[i].price)}`;
    }
    return d;
  };

  // Generate Confidence Interval filled envelope path
  const buildConfidenceIntervalPath = (): string => {
    const startIndex = filteredHistory.length - 1;
    if (startIndex < 0 || combinedPoints.length <= startIndex || !showConfidence) return '';

    let upperPoints: string[] = [];
    let lowerPoints: string[] = [];

    // First point connects precisely to historical close to avoid layout gaps
    const startX = getX(startIndex);
    const startY = getY(combinedPoints[startIndex].price);
    upperPoints.push(`${startX},${startY}`);
    lowerPoints.push(`${startX},${startY}`);

    for (let i = startIndex + 1; i < combinedPoints.length; i++) {
      const item = combinedPoints[i];
      if (item.upperBound !== undefined && item.lowerBound !== undefined) {
        upperPoints.push(`${getX(i)},${getY(item.upperBound)}`);
        lowerPoints.unshift(`${getX(i)},${getY(item.lowerBound)}`);
      }
    }

    const fullPolygonString = upperPoints.concat(lowerPoints).join(' ');
    return fullPolygonString;
  };

  // Generate filled area under historical prices
  const buildBaseAreaPath = (): string => {
    const linePath = buildMainLinePath();
    if (!linePath) return '';
    const lastX = getX(filteredHistory.length - 1);
    const bottomY = height - paddingBottom - volumeChartHeightRange;
    const firstX = getX(0);
    return `${linePath} L ${lastX} ${bottomY} L ${firstX} ${bottomY} Z`;
  };

  // Gather Y-axis pricing ticks (e.g. 5 ticks)
  const yTicks: number[] = [];
  const tickCount = 5;
  for (let i = 0; i < tickCount; i++) {
    const priceVal = minPrice + ((maxPrice - minPrice) * i) / (tickCount - 1);
    yTicks.push(priceVal);
  }

  // Gather X-axis index labels (e.g. 5 ticks across width)
  const xIndices: number[] = [];
  const xTickInterval = Math.max(1, Math.floor(totalSlots / 6));
  for (let i = 0; i < totalSlots; i += xTickInterval) {
    xIndices.push(i);
  }
  // Ensure final forecast endpoint date label is visible
  if (!xIndices.includes(totalSlots - 1)) {
    xIndices.push(totalSlots - 1);
  }

  // Technical overlay lines path building helper
  const buildIndicatorPath = (values: (number | null)[]): string => {
    let d = '';
    let started = false;
    for (let i = 0; i < values.length; i++) {
      const val = values[i];
      if (val !== null) {
        const x = getX(i);
        const y = getY(val);
        if (!started) {
          d += `M ${x} ${y}`;
          started = true;
        } else {
          d += ` L ${x} ${y}`;
        }
      }
    }
    return d;
  };

  // Bollinger Bands upper boundary, lower boundary, or closed shaded channel
  const buildBollingerAreaPath = (): string => {
    let upperPoints: string[] = [];
    let lowerPoints: string[] = [];
    let started = false;

    for (let i = 0; i < bbUpper.length; i++) {
      const activeUpper = bbUpper[i];
      const activeLower = bbLower[i];
      if (activeUpper !== null && activeLower !== null) {
        upperPoints.push(`${getX(i)},${getY(activeUpper)}`);
        lowerPoints.unshift(`${getX(i)},${getY(activeLower)}`);
      }
    }

    if (upperPoints.length === 0) return '';
    return upperPoints.concat(lowerPoints).join(' ');
  };

  // Linear Regression highlight lookback path
  const buildRegressionFittingLinePath = (): string => {
    const histLen = filteredHistory.length;
    if (histLen < 2) return '';
    
    // Find fitted regression points across historical Lookback period
    const lookbackStartIdx = Math.max(0, histLen - lookbackPeriod);
    const lookbackPointsRange = filteredHistory.slice(lookbackStartIdx);
    
    // Read the slope indicator values calculated in math
    // For rendering, we can map first lookbackPoint index to its price, and final index to forecast start
    // Wait, let's extract the fitted regression line mathematically
    let sumX = 0, sumY = 0, sumXY = 0, sumXX = 0;
    const n = lookbackPointsRange.length;
    for (let i = 0; i < n; i++) {
      const x = i;
      const y = lookbackPointsRange[i].close;
      sumX += x;
      sumY += y;
      sumXY += x * y;
      sumXX += x * x;
    }
    const den = n * sumXX - sumX * sumX;
    if (den === 0) return '';
    const m = (n * sumXY - sumX * sumY) / den;
    const b = (sumY - m * sumX) / n;

    const startXCoord = getX(lookbackStartIdx);
    const startYCoord = getY(m * 0 + b);
    const endXCoord = getX(histLen - 1);
    const endYCoord = getY(m * (n - 1) + b);

    return `M ${startXCoord} ${startYCoord} L ${endXCoord} ${endYCoord}`;
  };

  return (
    <div id="graphics-panel" className="bg-[#0A0A0A] border border-[#222] rounded-3xl p-6 shadow-xl flex flex-col gap-4">
      {/* Top Controls Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b border-[#222] pb-4">
        <div className="flex items-center gap-2">
          <LayoutGrid className="w-5 h-5 text-indigo-400" />
          <h2 className="text-base font-bold text-white tracking-tight">
            Interactive Forecast Canvas (Horizon: +{forecastHorizon}d)
          </h2>
        </div>

        {/* Dynamic Preset Timeframes selector */}
        <div className="flex items-center gap-1 bg-[#111] border border-[#222] p-1 rounded-2xl">
          {(['3M', '6M', '1Y', 'ALL'] as const).map(tf => (
            <button
              key={tf}
              onClick={() => setTimeframe(tf)}
              className={`px-3 py-1 rounded-xl text-xs leading-none transition-all cursor-pointer font-bold ${
                timeframe === tf
                  ? 'bg-[#1C1C1E] border border-[#222] text-white'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {tf}
            </button>
          ))}
        </div>
      </div>

      {/* SVG Canvas Arena */}
      <div className="relative bg-[#111]/40 border border-[#222] rounded-2xl overflow-hidden p-1">
        <svg
          ref={svgRef}
          viewBox={`0 0 ${width} ${height}`}
          className="w-full h-auto max-h-[440px] select-none cursor-crosshair text-slate-600"
          onMouseMove={handleMouseMove}
          onMouseLeave={handleMouseLeave}
        >
          {/* Definitions for Gradients */}
          <defs>
            {/* Historical Area Fill Gradient */}
            <linearGradient id="historyAreaGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#14b8a6" stopOpacity="0.12" />
              <stop offset="100%" stopColor="#14b8a6" stopOpacity="0.00" />
            </linearGradient>

            {/* Prediction Spread Gradient */}
            <linearGradient id="predictionAreaGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#6366f1" stopOpacity="0.06" />
              <stop offset="100%" stopColor="#6366f1" stopOpacity="0.00" />
            </linearGradient>
          </defs>

          {/* Gridlines along values */}
          {yTicks.map((val, idx) => (
            <g key={`grid-y-${idx}`}>
              <line
                x1={paddingLeft}
                y1={getY(val)}
                x2={width - paddingRight}
                y2={getY(val)}
                stroke="#1e293b"
                strokeWidth="1"
                strokeDasharray="2,5"
              />
              <text
                x={paddingLeft - 8}
                y={getY(val) + 4}
                textAnchor="end"
                className="font-mono text-[10px] fill-slate-500 font-bold"
              >
                ${val.toFixed(0)}
              </text>
            </g>
          ))}

          {/* Bollinger Band overlay background channel */}
          {showBollinger && (
            <polygon
              points={buildBollingerAreaPath()}
              fill="#2563eb"
              fillOpacity="0.05"
            />
          )}

          {/* Forecast Uncertainty Bounds shaded channel */}
          {showConfidence && (
            <polygon
              points={buildConfidenceIntervalPath()}
              fill="url(#predictionAreaGrad)"
            />
          )}

          {/* History filled background area */}
          <path
            d={buildBaseAreaPath()}
            fill="url(#historyAreaGrad)"
          />

          {/* Bollinger Band upper & lower outline rails */}
          {showBollinger && (
            <>
              <path
                d={buildIndicatorPath(bbUpper)}
                fill="none"
                stroke="#2563eb"
                strokeWidth="1"
                strokeDasharray="3,3"
                opacity="0.5"
              />
              <path
                d={buildIndicatorPath(bbLower)}
                fill="none"
                stroke="#2563eb"
                strokeWidth="1"
                strokeDasharray="3,3"
                opacity="0.5"
              />
            </>
          )}

          {/* 20-day Simple Moving Average Curve */}
          {showSMA && (
            <path
              d={buildIndicatorPath(smaValues)}
              fill="none"
              stroke="#a855f7"
              strokeWidth="1.5"
              strokeDasharray="4,2"
              opacity="0.85"
            />
          )}

          {/* 20-day Exponential Moving Average Curve */}
          {showEMA && (
            <path
              d={buildIndicatorPath(emaValues)}
              fill="none"
              stroke="#f97316"
              strokeWidth="1.5"
              strokeDasharray="4,2"
              opacity="0.85"
            />
          )}

          {/* Regression baseline lookback range highlighter */}
          <path
            d={buildRegressionFittingLinePath()}
            fill="none"
            stroke="#f59e0b"
            strokeWidth="1.2"
            strokeDasharray="2,3"
            opacity="0.85"
          />

          {/* Bounding divider for historical training lookback block */}
          {filteredHistory.length > lookbackPeriod && (
            <line
              x1={getX(filteredHistory.length - lookbackPeriod)}
              y1={paddingTop}
              x2={getX(filteredHistory.length - lookbackPeriod)}
              y2={height - paddingBottom - volumeChartHeightRange}
              stroke="#eab308"
              strokeWidth="1"
              strokeDasharray="6,4"
              opacity="0.4"
            />
          )}

          {/* Main historical prices line path */}
          <path
            d={buildMainLinePath()}
            fill="none"
            stroke="#14b8a6"
            strokeWidth="2.5"
            strokeLinecap="round"
          />

          {/* Solid line representing Forecast price projections */}
          <path
            d={buildForecastPath()}
            fill="none"
            stroke="#6366f1"
            strokeWidth="2.5"
            strokeLinecap="round"
          />

          {/* Forecast Spread Upper and Lower thin boundaries */}
          {showConfidence && (
            <>
              <path
                d={buildIndicatorPath(combinedPoints.map(p => p.upperBound !== undefined ? p.upperBound : null))}
                fill="none"
                stroke="#a5b4fc"
                strokeWidth="1"
                opacity="0.4"
              />
              <path
                d={buildIndicatorPath(combinedPoints.map(p => p.lowerBound !== undefined ? p.lowerBound : null))}
                fill="none"
                stroke="#a5b4fc"
                strokeWidth="1"
                opacity="0.4"
              />
            </>
          )}

          {/* Volume visual bar chart on background */}
          {filteredHistory.map((h, idx) => {
            const isUp = h.close >= h.open;
            const x = getX(idx);
            const w = Math.max(1.5, (width - paddingLeft - paddingRight) / totalSlots - 1);
            const y = getVolY(h.volume, maxVolume);
            const hCoord = height - paddingBottom - y;
            return (
              <rect
                key={`volume-bar-${idx}`}
                x={x - w / 2}
                y={y}
                width={w}
                height={Math.max(1, hCoord)}
                fill={isUp ? '#10b981' : '#ef4444'}
                fillOpacity="0.22"
              />
            );
          })}

          {/* Timeline label parameters at axes */}
          {xIndices.map((ptIdx) => (
            <g key={`label-x-${ptIdx}`}>
              <line
                x1={getX(ptIdx)}
                y1={height - paddingBottom - volumeChartHeightRange}
                x2={getX(ptIdx)}
                y2={height - paddingBottom - volumeChartHeightRange + 6}
                stroke="#334155"
                strokeWidth="1"
              />
              <text
                x={getX(ptIdx)}
                y={height - paddingBottom + 16}
                textAnchor="middle"
                className="font-mono text-[9px] fill-slate-500 font-bold"
              >
                {combinedPoints[ptIdx]?.date.slice(5) || ''}
              </text>
            </g>
          ))}

          {/* Vertical dash separating forecast horizon beginning */}
          <line
            x1={getX(filteredHistory.length - 1)}
            y1={paddingTop}
            x2={getX(filteredHistory.length - 1)}
            y2={height - paddingBottom}
            stroke="#6366f1"
            strokeWidth="1.2"
            strokeDasharray="4,4"
            opacity="0.7"
          />

          {/* Interactive cursor indicator hover crosshair paths */}
          {hoverData && (
            <g id="interactive-crosshairs">
              {/* Vertical crosshair */}
              <line
                x1={hoverData.x}
                y1={paddingTop}
                x2={hoverData.x}
                y2={height - paddingBottom}
                stroke="#ffffff"
                strokeWidth="0.8"
                strokeDasharray="3,3"
                opacity="0.6"
              />
              {/* Horizontal crosshair */}
              <line
                x1={paddingLeft}
                y1={hoverData.y}
                x2={width - paddingRight}
                y2={hoverData.y}
                stroke="#ffffff"
                strokeWidth="0.8"
                strokeDasharray="3,3"
                opacity="0.5"
              />
              {/* Price anchoring hub node */}
              <circle
                cx={hoverData.x}
                cy={hoverData.y}
                r="5"
                fill={hoverData.isForecast ? '#818cf8' : '#2dd4bf'}
                stroke="#ffffff"
                strokeWidth="2"
              />
            </g>
          )}
        </svg>

        {/* Floating crosshair details card */}
        {hoverData && (
          <div
            id="chart-hover-tip"
            className="absolute bg-slate-900/95 border border-slate-700/80 p-3.5 rounded-xl text-left pointer-events-none text-xs flex flex-col gap-1.5 shadow-2xl z-20 backdrop-blur-md"
            style={{
              left: hoverData.x > width / 2 ? `${hoverData.x * 0.118 - 14}rem` : `${hoverData.x * 0.118 + 1}rem`,
              top: '1.25rem',
              width: '14rem'
            }}
          >
            <div className="flex items-center justify-between border-b border-slate-800 pb-1.5 mb-1">
              <span className="font-bold text-white font-mono">{hoverData.date}</span>
              <span className={`px-2 py-0.5 rounded text-[9px] font-bold uppercase tracking-wider ${
                hoverData.isForecast ? 'bg-indigo-600/30 text-indigo-300' : 'bg-teal-500/10 text-teal-400'
              }`}>
                {hoverData.isForecast ? 'Predicted' : 'Historical Price'}
              </span>
            </div>

            <div className="flex justify-between items-baseline font-mono text-[11px] leading-relaxed">
              <span className="text-slate-400">Close Price:</span>
              <span className="text-white font-bold text-sm">${hoverData.price.toFixed(2)}</span>
            </div>

            {!hoverData.isForecast && hoverData.open !== undefined && (
              <>
                <div className="flex justify-between font-mono text-[10px] text-slate-500">
                  <span>Open:</span>
                  <span className="text-slate-300 font-bold">${hoverData.open.toFixed(2)}</span>
                </div>
                <div className="flex justify-between font-mono text-[10px] text-slate-500">
                  <span>Range (H-L):</span>
                  <span className="text-slate-300 font-bold">${hoverData.high?.toFixed(2)} - ${hoverData.low?.toFixed(2)}</span>
                </div>
                <div className="flex justify-between font-mono text-[10px] text-slate-500">
                  <span>Volume:</span>
                  <span className="text-slate-300 font-bold">{hoverData.volume?.toLocaleString()}</span>
                </div>
              </>
            )}

            {hoverData.isForecast && hoverData.lowerBound !== undefined && (
              <div className="flex flex-col gap-0.5 bg-indigo-950/20 border border-indigo-900/40 p-1.5 rounded-lg">
                <span className="text-[9px] text-indigo-400 font-bold uppercase tracking-widest leading-none">Confidence Spreads</span>
                <div className="flex justify-between font-mono text-[10px] mt-1 text-indigo-300 leading-none">
                  <span>Max Limit:</span>
                  <span className="font-bold">${hoverData.upperBound?.toFixed(2)}</span>
                </div>
                <div className="flex justify-between font-mono text-[10px] text-indigo-300 mt-1 leading-none">
                  <span>Min Limit:</span>
                  <span className="font-bold">${hoverData.lowerBound?.toFixed(2)}</span>
                </div>
              </div>
            )}

            {/* overlays metrics details if they exist */}
            {(hoverData.sma !== null || hoverData.ema !== null || hoverData.bbUpper !== null) && (
              <div className="border-t border-slate-800 pt-1.5 mt-1 flex flex-col gap-1 text-[10px] font-mono">
                {hoverData.sma !== null && (
                  <div className="flex justify-between text-purple-300">
                    <span>20-day SMA:</span>
                    <span className="font-bold">${hoverData.sma.toFixed(2)}</span>
                  </div>
                )}
                {hoverData.ema !== null && (
                  <div className="flex justify-between text-orange-300">
                    <span>20-day EMA:</span>
                    <span className="font-bold">${hoverData.ema.toFixed(2)}</span>
                  </div>
                )}
                {hoverData.bbUpper !== null && (
                  <div className="flex justify-between text-blue-300">
                    <span>BB Channel:</span>
                    <span className="font-bold">${hoverData.bbLower?.toFixed(1)} - ${hoverData.bbUpper.toFixed(1)}</span>
                  </div>
                )}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Legend Settings Overlay Controls */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {/* SMA Toggle Button */}
        <button
          onClick={() => setShowSMA(!showSMA)}
          className={`flex items-center justify-between px-4 py-2 rounded-xl text-xs border transition-all cursor-pointer ${
            showSMA
              ? 'bg-purple-500/10 border-purple-550 text-purple-300'
              : 'bg-[#111] border-[#222] text-[#888] hover:text-white'
          }`}
        >
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-purple-500"></span>
            <span className="font-bold">20d SMA</span>
          </div>
          {showSMA ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
        </button>

        {/* EMA Toggle Button */}
        <button
          onClick={() => setShowEMA(!showEMA)}
          className={`flex items-center justify-between px-4 py-2 rounded-xl text-xs border transition-all cursor-pointer ${
            showEMA
              ? 'bg-orange-500/10 border-orange-550 text-orange-400'
              : 'bg-[#111] border-[#222] text-[#888] hover:text-white'
          }`}
        >
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-orange-400"></span>
            <span className="font-bold">20d EMA</span>
          </div>
          {showEMA ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
        </button>

        {/* Bollinger Bands Toggle button */}
        <button
          onClick={() => setShowBollinger(!showBollinger)}
          className={`flex items-center justify-between px-4 py-2 rounded-xl text-xs border transition-all cursor-pointer ${
            showBollinger
              ? 'bg-blue-500/10 border-blue-550 text-blue-300'
              : 'bg-[#111] border-[#222] text-[#888] hover:text-white'
          }`}
        >
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded bg-blue-500"></span>
            <span className="font-bold">Bollinger Bands</span>
          </div>
          {showBollinger ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
        </button>

        {/* Confidence Interval spreads Toggle */}
        <button
          onClick={() => setShowConfidence(!showConfidence)}
          className={`flex items-center justify-between px-4 py-2 rounded-xl text-xs border transition-all cursor-pointer ${
            showConfidence
              ? 'bg-indigo-500/10 border-indigo-550 text-indigo-400'
              : 'bg-[#111] border-[#222] text-[#888] hover:text-white'
          }`}
        >
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded bg-indigo-500/30 border border-indigo-400"></span>
            <span className="font-bold">Confidence Spreads</span>
          </div>
          {showConfidence ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
        </button>
      </div>
    </div>
  );
}
