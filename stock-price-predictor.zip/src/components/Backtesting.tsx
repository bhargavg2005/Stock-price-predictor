import { TrendingUp, AlertCircle, Sparkles, CheckCircle, HelpCircle } from 'lucide-react';
import { BacktestResult, StockSymbol } from '../types';

interface BacktestingProps {
  symbol: StockSymbol;
  backtestResult: BacktestResult;
  modelName: string;
}

export function Backtesting({ symbol, backtestResult, modelName }: BacktestingProps) {
  const { mae, rmse, mape, rSquared, directionAccuracy, predictedVsActual } = backtestResult;

  // Render a mini SVG for comparing the predicted vs actual lines
  const width = 600;
  const height = 180;
  const paddingLeft = 40;
  const paddingRight = 15;
  const paddingTop = 15;
  const paddingBottom = 25;

  const actualPrices = predictedVsActual.map(p => p.actual);
  const predictedPrices = predictedVsActual.map(p => p.predicted);
  const allPrices = [...actualPrices, ...predictedPrices];
  
  const minPrice = Math.min(...allPrices) * 0.98;
  const maxPrice = Math.max(...allPrices) * 1.02;
  const slots = predictedVsActual.length;

  const getX = (idx: number): number => {
    return paddingLeft + ((width - paddingLeft - paddingRight) * idx) / Math.max(1, slots - 1);
  };

  const getY = (price: number): number => {
    const range = maxPrice - minPrice || 1;
    return height - paddingBottom - ((height - paddingTop - paddingBottom) * (price - minPrice)) / range;
  };

  // Build SVG Paths
  const buildPath = (prices: number[]): string => {
    let d = '';
    prices.forEach((p, idx) => {
      const x = getX(idx);
      const y = getY(p);
      if (idx === 0) d += `M ${x} ${y}`;
      else d += ` L ${x} ${y}`;
    });
    return d;
  };

  // Grade the accuracy based on Mean Absolute Percentage Error (MAPE)
  let grade = 'F';
  let gradeColor = 'text-rose-400 border-rose-500/30 bg-rose-500/10';
  let ratingVerdict = 'Inaccurate';
  const explanationText = `The ${modelName} model was fit on historical prices preceding the final ${slots} days, treating that final slice as an unseen validation set. Metrics are computed by comparing rolling predictions directly with historical actuals.`;

  if (mape <= 2.5) {
    grade = 'A+';
    gradeColor = 'text-teal-400 border-teal-500/30 bg-teal-500/10';
    ratingVerdict = 'Exceptional Match';
  } else if (mape <= 5) {
    grade = 'A';
    gradeColor = 'text-teal-400 border-teal-500/30 bg-teal-500/10';
    ratingVerdict = 'Excellent Accuracy';
  } else if (mape <= 8) {
    grade = 'B';
    gradeColor = 'text-emerald-400 border-emerald-500/30 bg-emerald-500/10';
    ratingVerdict = 'Highly Reliable';
  } else if (mape <= 12) {
    grade = 'C';
    gradeColor = 'text-amber-400 border-amber-500/30 bg-amber-500/10';
    ratingVerdict = 'Moderate Fits';
  } else if (mape <= 18) {
    grade = 'D';
    gradeColor = 'text-orange-400 border-orange-500/30 bg-orange-500/10';
    ratingVerdict = 'Speculative Sizing';
  } else {
    grade = 'F';
    gradeColor = 'text-rose-400 border-rose-500/30 bg-rose-500/10';
    ratingVerdict = 'High Deviation';
  }

  return (
    <div id="backtest-panel" className="bg-[#0A0A0A] border border-[#222] rounded-3xl p-6 shadow-xl text-left flex flex-col gap-6">
      {/* Module Title */}
      <div className="flex items-center gap-2 border-b border-[#222] pb-4 justify-between">
        <div className="flex items-center gap-2">
          <TrendingUp className="w-5 h-5 text-indigo-400" />
          <h2 className="text-base font-bold text-white tracking-tight">Model Backtesting Scorecard</h2>
        </div>
        <span className="text-[10px] font-mono bg-[#111] text-slate-400 border border-[#222] px-2 py-0.5 rounded uppercase tracking-wider font-bold">
          Validation Sample: {slots}d
        </span>
      </div>

      {/* Main explanation text */}
      <p className="text-[11px] leading-relaxed text-slate-400">
        {explanationText}
      </p>

      {/* Primary Grid Layout: Stats on Left, Quick Compare Chart on Right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
        
        {/* Metric scorecard statistics: Left Column */}
        <div className="lg:col-span-5 flex flex-col gap-4">
          <div className="flex gap-3 items-center">
            <div className={`w-14 h-14 rounded-2xl border text-xl font-black flex items-center justify-center font-mono shadow-md ${gradeColor}`}>
              {grade}
            </div>
            <div className="flex flex-col">
              <span className="text-xs font-bold text-slate-500 uppercase tracking-widest">Backtest Performance</span>
              <span className="text-base font-extrabold text-white leading-tight">{ratingVerdict}</span>
              <span className="text-[10px] text-slate-400 mt-1">MAPE Deviation Score: {mape.toFixed(2)}%</span>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2 mt-2 font-mono">
            {/* Direction Accuracy */}
            <div className="bg-[#111] border border-[#222] p-2.5 rounded-2xl flex flex-col">
              <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider leading-none">Trend Accuracy</span>
              <span className="text-base font-bold text-white mt-1.5">{directionAccuracy.toFixed(1)}%</span>
              <span className="text-[9px] text-slate-400 mt-1">Direction hits</span>
            </div>
            
            {/* R-Squared Metric */}
            <div className="bg-[#111] border border-[#222] p-2.5 rounded-2xl flex flex-col">
              <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider leading-none">R² Fit Quality</span>
              <span className={`text-base font-bold mt-1.5 ${rSquared > 0 ? 'text-emerald-400' : 'text-slate-400'}`}>
                {rSquared.toFixed(3)}
              </span>
              <span className="text-[9px] text-slate-400 mt-1">Proximity to actual</span>
            </div>

            {/* Mean Absolute Error */}
            <div className="bg-[#111] border border-[#222] p-2.5 rounded-2xl flex flex-col">
              <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider leading-none">Mean Abs Error</span>
              <span className="text-sm font-bold text-white mt-1.5">${mae.toFixed(1)}</span>
              <span className="text-[9px] text-slate-400 mt-1">Average daily sway</span>
            </div>

            {/* RMSE */}
            <div className="bg-[#111] border border-[#222] p-2.5 rounded-2xl flex flex-col">
              <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider leading-none">RMS Deviation</span>
              <span className="text-sm font-bold text-white mt-1.5">${rmse.toFixed(1)}</span>
              <span className="text-[9px] text-slate-400 mt-1">Stochastic error penalty</span>
            </div>
          </div>
        </div>

        {/* mini visual reference vector line comparing actuals: Right Column */}
        <div className="lg:col-span-7 bg-[#111] border border-[#222] rounded-2xl p-4 flex flex-col">
          <div className="flex justify-between items-center text-[10px] font-bold uppercase pb-2 mb-1 border-b border-[#222] leading-none">
            <span className="text-slate-400 tracking-wider">Historical Spliced Validation Fit</span>
            <div className="flex items-center gap-3">
              <span className="flex items-center gap-1 text-teal-400">
                <span className="inline-block w-2.5 h-[2px] bg-teal-400"></span> Actual
              </span>
              <span className="flex items-center gap-1 text-indigo-400">
                <span className="inline-block w-2.5 h-[2px] bg-indigo-400"></span> Fit
              </span>
            </div>
          </div>

          <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-auto max-h-[140px] text-slate-800">
            {/* Draw grid references */}
            <line x1={paddingLeft} y1={paddingTop} x2={width - paddingRight} y2={paddingTop} stroke="#1A1A1A" strokeDasharray="3,3" />
            <line x1={paddingLeft} y1={height - paddingBottom} x2={width - paddingRight} y2={height - paddingBottom} stroke="#1A1A1A" />

            {/* Price values label */}
            <text x={paddingLeft - 6} y={paddingTop + 4} textAnchor="end" className="text-[9px] font-mono fill-slate-500 font-semibold">${maxPrice.toFixed(0)}</text>
            <text x={paddingLeft - 6} y={height - paddingBottom + 3} textAnchor="end" className="text-[9px] font-mono fill-slate-500 font-semibold">${minPrice.toFixed(0)}</text>

            {/* Draw Actual Line (Teal) */}
            <path
              d={buildPath(actualPrices)}
              fill="none"
              stroke="#14b8a6"
              strokeWidth="2"
              strokeLinecap="round"
            />

            {/* Draw Predicted/Backtest Fit Line (Indigo) */}
            <path
              d={buildPath(predictedPrices)}
              fill="none"
              stroke="#6366f1"
              strokeWidth="2"
              strokeDasharray="4,2"
              strokeLinecap="round"
            />

            {/* Date markers on bottom */}
            <text x={getX(0)} y={height - paddingBottom + 16} textAnchor="start" className="text-[9px] font-mono fill-slate-500">
              {predictedVsActual[0]?.date.slice(5) || ''}
            </text>
            <text x={getX(slots - 1)} y={height - paddingBottom + 16} textAnchor="end" className="text-[9px] font-mono fill-slate-500">
              {predictedVsActual[slots - 1]?.date.slice(5) || ''}
            </text>
          </svg>
        </div>

      </div>

      {/* Splicing parameters notice warning */}
      <div className="bg-[#111] p-3.5 border border-[#222] rounded-2xl flex gap-2 w-full">
        {mape <= 10 ? (
          <CheckCircle className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
        ) : (
          <AlertCircle className="w-5 h-5 text-amber-500 shrink-0 mt-0.5" />
        )}
        <div className="flex flex-col">
          <span className="text-xs font-bold text-white leading-none">
            {mape <= 10 ? 'Stable Forecast Confidence' : 'High Stochastic Drift Detected'}
          </span>
          <p className="text-[10px] text-slate-400 leading-normal mt-1">
            {mape <= 10
              ? 'Fitted residuals indicate durable trend compliance. Low tracking errors make regression forecasting highly suitable for this looking sequence.'
              : 'Asset values indicate high micro-volatility or rapid market reversals. Mathematical trends should be used carefully alongside AI fundamental reports.'}
          </p>
        </div>
      </div>
    </div>
  );
}
