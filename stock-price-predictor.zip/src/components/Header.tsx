import { TrendingUp, Award, Calendar, RefreshCcw } from 'lucide-react';
import { StockSymbol } from '../types';

interface HeaderProps {
  selectedSymbol: StockSymbol;
  setSelectedSymbol: (symbol: StockSymbol) => void;
  currentPrice: number;
  priceChange: number;
  priceChangePercent: number;
  onRefreshData: () => void;
  portfolioNetWorth: number;
}

export function Header({
  selectedSymbol,
  setSelectedSymbol,
  currentPrice,
  priceChange,
  priceChangePercent,
  onRefreshData,
  portfolioNetWorth,
}: HeaderProps) {
  const isPositive = priceChange >= 0;

  const symbolMetadata: Record<StockSymbol, { name: string; desc: string }> = {
    AAPL: { name: 'Apple Inc.', desc: 'Consumer Electronics & Spatial Computing' },
    TSLA: { name: 'Tesla Inc.', desc: 'Electric Vehicles & Clean Energy Solutions' },
    MSFT: { name: 'Microsoft Corp.', desc: 'Enterprise Cloud System & Copilot AI' },
    GOOGL: { name: 'Alphabet Inc.', desc: 'Global Search Engine & Gemini Neural Core' },
    NVDA: { name: 'NVIDIA Corporation', desc: 'AI Hardware Acceleration & GPU Architectures' },
    AMZN: { name: 'Amazon.com, Inc.', desc: 'Cloud Supercomputing & Global Logistics Retail' },
    'BTC-USD': { name: 'Bitcoin / USD', desc: 'Decentralized Blockchain Protocol Reserve' },
  };

  const symbols: StockSymbol[] = ['AAPL', 'MSFT', 'NVDA', 'TSLA', 'GOOGL', 'AMZN', 'BTC-USD'];

  return (
    <header id="header-bar" className="bg-[#0A0A0A] border-b border-[#222] py-4 px-6 sticky top-0 z-40 font-sans">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        {/* Left Side: Brand Name & Symbol Select */}
        <div className="flex flex-wrap items-center gap-4">
          <div className="flex items-center gap-2">
            <div className="bg-indigo-505 text-white p-2 rounded-xl font-bold flex items-center justify-center shadow-lg shadow-indigo-500/5">
              <TrendingUp className="w-5 h-5 text-indigo-400" />
            </div>
            <div>
              <h1 className="text-lg font-bold text-white tracking-tight leading-none">Stock Forecast</h1>
              <p className="text-xs text-slate-400">Mathematical & AI Predictor</p>
            </div>
          </div>

          <div className="h-8 w-[1px] bg-[#222] hidden sm:block"></div>

          {/* Symbol Selector Pill Bar */}
          <div className="flex items-center gap-1 bg-[#111] border border-[#222] p-1 rounded-2xl overflow-x-auto max-w-full">
            {symbols.map((symbol) => (
              <button
                key={symbol}
                id={`symbol-btn-${symbol}`}
                onClick={() => setSelectedSymbol(symbol)}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold tracking-wide transition-all cursor-pointer ${
                  selectedSymbol === symbol
                    ? 'bg-[#1C1C1E] text-white border border-[#222] font-semibold shadow-md'
                    : 'text-slate-400 hover:text-white hover:bg-[#1A1A1A]'
                }`}
              >
                {symbol === 'BTC-USD' ? 'BTC' : symbol}
              </button>
            ))}
          </div>
        </div>

        {/* Middle/Right Side: Mini Ticker Detail & Portfolio Quick Indicator */}
        <div id="ticker-details" className="flex flex-wrap items-center justify-between sm:justify-end gap-x-8 gap-y-2">
          {/* Current Selection Information */}
          <div className="flex flex-col">
            <div className="flex items-center gap-2">
              <span className="text-xs font-semibold text-slate-400">{symbolMetadata[selectedSymbol].name}</span>
              <button 
                onClick={onRefreshData}
                title="Regenerate seed history"
                className="text-slate-505 hover:text-indigo-400 transition-colors p-0.5 rounded-md hover:bg-[#111]"
              >
                <RefreshCcw className="w-3.5 h-3.5" />
              </button>
            </div>
            <div className="flex items-baseline gap-2">
              <span className="text-2xl font-mono font-bold text-white">
                ${currentPrice.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </span>
              <span className={`text-sm font-semibold flex items-center ${isPositive ? 'text-emerald-400' : 'text-rose-400'}`}>
                {isPositive ? '+' : ''}
                {priceChangePercent.toFixed(2)}%
              </span>
            </div>
          </div>

          <div className="h-8 w-[1px] bg-[#222] hidden sm:block"></div>

          {/* Quick Portfolio Valuation Stat */}
          <div className="flex items-center gap-3 bg-[#111] border border-[#222] py-1.5 px-3 rounded-2xl shadow-inner">
            <div className="bg-indigo-600/10 border border-indigo-500/10 text-indigo-400 p-2 rounded-xl">
              <Award className="w-5 h-5 animate-pulse" />
            </div>
            <div className="text-left">
              <span className="text-[10px] font-bold text-slate-400 block tracking-wider uppercase leading-none">Paper Cash Value</span>
              <span className="text-base font-mono font-bold text-white">
                ${portfolioNetWorth.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </span>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}
