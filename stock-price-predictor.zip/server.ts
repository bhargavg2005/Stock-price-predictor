import express from 'express';
import path from 'path';
import { GoogleGenAI, Type } from '@google/genai';
import dotenv from 'dotenv';
import { createServer as createViteServer } from 'vite';

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Lazy initialized Gemini connection to prevent crashes on startup if secret key is missing
function getGeminiClient() {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error('GEMINI_API_KEY environment variable is missing. Click on "Settings" and add it under "Secrets".');
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// REST route for health checking
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', time: new Date().toISOString() });
});

// AI analysis proxy API endpoint
app.post('/api/analyze', async (req, res) => {
  try {
    const { symbol, currentPrice, high, low, trend, lookbackDays, indicators, recentNews } = req.body;
    
    let ai;
    try {
      ai = getGeminiClient();
    } catch (err: any) {
      return res.status(403).json({
        error: 'KeyMissing',
        message: err.message
      });
    }

    const newsContext = recentNews && recentNews.length > 0
      ? recentNews.map((n: any) => `- TITLE: "${n.title}" (Sentiment: ${n.sentiment}, Score: ${n.score}) - SUMMARY: ${n.summary}`).join('\n')
      : 'No dynamic news registered for today.';

    const systemPrompt = `You are a professional, senior Quantitative Stock Analyst and Forecaster. 
Your objective is to review historical stock metrics, indicators, and sentiment feed items, and generate a structured forecasting report. 
Do not contain any raw markdown like \`\`\`json outside the expected structured output. Deliver accurate, professional, human-grade numeric boundaries.`;

    const promptMessage = `Please analyze the following asset metrics and generate a full 30-day outlook prediction report:
      
Asset Symbol: ${symbol}
Current Price: $${currentPrice} (Daily Range: $${low} - $${high})
Model Training Lookback: Last ${lookbackDays} days
Trend Direction: ${trend}

Technical Indicators calculated:
- 20-day Simple Moving Average (SMA): ${indicators.sma || 'Calculating...'}
- 20-day Exponential Moving Average (EMA): ${indicators.ema || 'Calculating...'}
- Bollinger Bands Upper: ${indicators.bollingerUpper || 'Calculating...'}
- Bollinger Bands Lower: ${indicators.bollingerLower || 'Calculating...'}
- Fitted Linear Regression slope line: ${indicators.regressionLine || 'Calculating...'}

Recent News & Sentiment Events:
${newsContext}

Based on this historical and contextual data, compute the predicted sentiment score, market outlook recommendation, 30-day realistic target price boundaries, probability distribution, and technical summary.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.5-flash',
      contents: promptMessage,
      config: {
        systemInstruction: systemPrompt,
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            sentimentScore: { 
              type: Type.NUMBER, 
              description: 'Numerical market sentiment range in percentage scale from -100 (extreme panic/bearish) to +100 (extreme frenzy/bullish).' 
            },
            marketOutlook: { 
              type: Type.STRING, 
              description: 'Recommendation action: STRONG_BUY, BUY, HOLD, SELL, or STRONG_SELL.' 
            },
            targetPriceRange: {
              type: Type.OBJECT,
              properties: {
                min: { type: Type.NUMBER, description: 'Lower boundary estimation of the predicted price in 30 days.' },
                max: { type: Type.NUMBER, description: 'Upper boundary estimation of the predicted price in 30 days.' }
              },
              required: ['min', 'max']
            },
            probabilities: {
              type: Type.OBJECT,
              properties: {
                bullish: { type: Type.NUMBER, description: 'Probability percentage (0 to 100) of overall upward movement.' },
                neutral: { type: Type.NUMBER, description: 'Probability percentage (0 to 100) of overall sideways consolidation.' },
                bearish: { type: Type.NUMBER, description: 'Probability percentage (0 to 100) of overall downward movement.' }
              },
              required: ['bullish', 'neutral', 'bearish']
            },
            executiveSummary: { 
              type: Type.STRING, 
              description: 'Executive text review analyzing market catalysts, inflation indices, Fed parameters, demand, and overall trend logic.' 
            },
            catalysts: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: 'List of exactly 3 realistic, specific stock-specific or macro catalysts that could spark an upward breakout.'
            },
            risks: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: 'List of exactly 3 downside risk triggers that could spark a major downward selloff.'
            },
            technicalAssessment: { 
              type: Type.STRING, 
              description: 'Brief paragraph reviewing how the SMA, EMA, Bollinger bands support, resistance, and regression trends validate your outlook.' 
            }
          },
          required: [
            'sentimentScore',
            'marketOutlook',
            'targetPriceRange',
            'probabilities',
            'executiveSummary',
            'catalysts',
            'risks',
            'technicalAssessment'
          ]
        }
      }
    });

    const reportText = response.text || '{}';
    const reportData = JSON.parse(reportText);
    
    return res.json({ report: reportData });
  } catch (err: any) {
    console.error('AI Analysis failed:', err);
    return res.status(500).json({
      error: 'ServerError',
      message: err.message || 'An unexpected failure occurred while invoking Gemini.'
    });
  }
});

// Setup Vite Dev Server / Static Assets static serving with wrapping to avoid top-level await in esbuild CommonJS format
async function startMasterServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  // Bind server for Cloud Run
  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server started in ${process.env.NODE_ENV === 'production' ? 'production' : 'development'} mode.`);
    console.log(`Listening on http://localhost:${PORT}`);
  });
}

startMasterServer();
